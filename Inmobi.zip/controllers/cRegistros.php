<?php
    //controllers/..
    require '../fw/fw.php';
    require '../models/Registro.php';
    require '../models/Usuario.php';
    require '../views/vRegistros.php';

    if(!isset($_SESSION['logueado']))
    {
        header("Location: login");
        exit();
    }

    if(isset($_POST['cerrarSesion']))
    {
        unset($_SESSION['logueado']);
        unset($_SESSION['nombre']);
        header("Location: login");
        exit();
    }

    if(isset($_POST['user']))
    {
        $user = $_POST['user'];
        header("Location: usuarios-$user");
        exit();
    }

    
    $v = new vRegistros();
    $r = new Registro();
    $u = new Usuario();

    $v->task = $r->getTodos();
    $v->user = $u->getTodos();
    $v->render();
?>