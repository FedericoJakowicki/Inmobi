<?php
    //controllers/..
    require '../fw/fw.php';
    require '../models/Usuario.php';
    require "../models/Registro.php";
    require '../views/vUsuarios.php';
    require '../views/vCrearUsuario.php';

    if(!isset($_SESSION['logueado']))
    {
        header("Location: login");
        exit();
    }

    if(isset($_POST['cerrarSesion']))
    {
        unset($_SESSION['logueado']);
        unset($_SESSION['nombre']);
        header("Location: login");
        exit();
    }

    $u = new Usuario();

    if(isset($_POST['borrar_usuario']))
    {
        $u->set_usuario_inactivo($_POST['borrar_usuario']);

        $r = new Registro();
        $user = $u->getUsuario($_SESSION['nombre']);
        $user_delete = $u->getUsuario($_POST['borrar_usuario']);
        $nickname = $user_delete['nombre_usuario'];
        $nombre = $user_delete['nombre'];
        $apellido = $user_delete['apellido'];
        $r->newRegistro("Usuario borrado - $nickname - $nombre $apellido", $user['id_usuario']);
        header("Location: usuarios");
    }

    if(!isset($_POST['nuevo_usuario']))
    {
        if(!isset($_POST['new']))
        {
            $v = new vUsuarios();

            if(isset($_GET['user']))
                $v->selected = $_GET['user'];
            $v->user = $u->getTodos();
        }
        else
        {
            $v = new vCrearUsuario();
            $v->user = $u->getTodos();
        }
    }
    else
    {
        if(!isset($_POST['nickname']) || !isset($_POST['nombre']) || !isset($_POST['apellido']) ||
            !isset($_POST['telefono']) || !isset($_POST['email']) || !isset($_POST['contraseña']) ||
            !isset($_POST['nivel']))
        {
            die("Error datos faltantes");
            exit;
        }

        $u->newUsuario($_POST['nickname'], $_POST['contraseña'], $_POST['nombre'], $_POST['apellido'], 
                        $_POST['email'], $_POST['telefono'], $_POST['nivel']);

        $r = new Registro();
        $user = $u->getUsuario($_SESSION['nombre']);
        $nickname = $_POST['nickname'];
        $nombre = $_POST['nombre'];
        $apellido = $_POST['apellido'];
        $r->newRegistro("Usuario creado - $nickname - $nombre $apellido", $user['id_usuario']);
        
        header("Location: usuarios");
    }
    

    $v->render();
?>