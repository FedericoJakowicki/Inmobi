<?php
    //controllers/..
    require '../fw/fw.php';
    require "../models/Usuario.php";
    require "../models/Registro.php";
    require '../models/Ubicacion.php';
    require '../models/Propiedad.php';
    require '../models/Cliente.php';
    require '../models/Estado.php';
    require '../models/Tipo.php';
    require '../views/vPropiedades.php';
    require '../views/vPropiedad.php';
    require '../views/vCrearPropiedad.php';

    if(!isset($_SESSION['logueado']))
    {
        header("Location: login");
        exit();
    }

    if(isset($_POST['cerrarSesion']))
    {
        unset($_SESSION['logueado']);
        unset($_SESSION['nombre']);
        header("Location: login");
        exit();
    }

    if(isset($_POST['client']))
    {
        $id = $_POST['client'];
        header("Location: clientes-client-$id");
    }

    if(isset($_POST['cancelar']))
    {
        header("Location: propiedades");
        exit();
    }

    $p = new Propiedad();
    $ubicacion = new Ubicacion();
    
    if(isset($_POST['borrar_id']))
    {
        $p->set_prop_inactivo($_POST['borrar_id']);
        $prop = $p->getPropiedad($_POST['borrar_id']);

        $r = new Registro();
        $user = new Usuario();
        $user = $user->getUsuario($_SESSION['nombre']);
        $prov = $prop['provincia'];
        $loc = $prop['localidad'];
        $calle = $prop['calle'];
        $numero = $prop['numero'];
        $r->newRegistro("Propiedad borrada - Direccion - $prov, $loc, $calle $numero",$user['id_usuario']);
        
        header("Location: propiedades");
    }

    if(!isset($_POST['nueva_propiedad']))
    {
        if(!isset($_POST['new']))
        {
            if(!isset($_GET['prop']))
            {
                $v = new vPropiedades();
                $v->prop = $p->getTodos();
                $v->prov = $ubicacion->getProvincias();

                if(isset($_POST['provincia']))
                    $v->prefProv = $_POST['provincia']; 
                else
                    $v->prefProv = 0;

                if(isset($_POST['operacion']))
                    $v->prefOp = $_POST['operacion']; 
                else
                    $v->prefOp = 0;
            }
            else{
                $pr = $p->getPropiedad($_GET['prop']);
                
                if(!$pr['activo'])
                {
                    header("Location: propiedades");
                }
                else
                {
                    $comp = new Comprador;
                    $vc = new Vendedor_Comprador;
                    $v = new vPropiedad();

                    $v->comprador = array_merge($comp->getTodos(), $vc->getTodos());
                }

                $v->prop = $pr;
            }
        }
        else
        {
            $v = new vCrearPropiedad();
            $ve = new Vendedor();
            $vc = new Vendedor_Comprador();
            $estados = new Estado();
            $tipos = new Tipo();
            $v->prov = $ubicacion->getProvincias();
            $v->loc = $ubicacion->getLocalidades();
            $v->cond = $estados->getEstados();
            $v->type = $tipos->getTipos();
            $v->clients = array_merge($ve->getTodos(), $vc->getTodos());
        }
    }
    else
    {
        //VALIDACIONES
        $dueño = new Vendedor();
        if(!$dueño = $dueño->getVendedor($_POST['dueño']))
        {
            $dueño = new Vendedor_Comprador();
            if(!$dueño = $dueño->getVendedorComprador($_POST['dueño']))
                {die("Dueño inexistente"); exit;}
        } 
        if(!isset($_POST['c_terraza'])) $c_terraza = false; else $c_terraza = true;
        if(!isset($_POST['c_garage'])) $c_garage = false; else $c_garage = true;
        if(!isset($_POST['c_balcon'])) $c_balcon = false; else $c_balcon = true;
        if(!isset($_POST['c_pileta'])) $c_pileta = false; else $c_pileta = true;
        if(!isset($_POST['c_patio'])) $c_patio = false; else $c_patio = true;
        if(!isset($_POST['c_jardin'])) $c_jardin = false; else $c_jardin = true;
        if(!isset($_POST['muebles'])) $muebles = false; else $muebles = true;
        if(!isset($_POST['reservado'])) $reservado = false; else $reservado = true;
        if(!isset($_POST['operacion'])) {die("Falta operacion"); exit;}
        if(!isset($_POST['descripcion'])) {die("Falta descripcion"); exit;}
        if(!isset($_POST['precio'])) {die("Falta precio"); exit;}
        if(!isset($_POST['estado'])) {die("Falta estado"); exit;}
        if(!isset($_POST['baños'])) {die("Falta cant baños"); exit;}
        if(!isset($_POST['habitaciones'])) {die("Falta habitaciones"); exit;}
        if(!isset($_POST['tipo'])) {die("Falta tipo"); exit;}
        if(!isset($_POST['tamaño'])) {die("Falta tamaño"); exit;}
        if(!isset($_POST['dir_calle'])) {die("Falta calle"); exit;}
        if(!isset($_POST['dir_numero'])) {die("Falta numero"); exit;}
        if(!isset($_POST['localidad'])) {die("Falta localidad"); exit;}

        $detalle = array(
            'descripcion' => $_POST['descripcion'],
            'precio' => $_POST['precio'],
            'estado' => $_POST['estado'],
            'baños' => $_POST['baños'],
            'habitaciones' => $_POST['habitaciones'],
            'tipo' => $_POST['tipo'],
            'tamaño' => $_POST['tamaño'],
            'muebles' => $muebles,
            'caracteristicas' => array(
                'terraza' => $c_terraza,
                'garage' => $c_garage,
                'balcon' => $c_balcon,
                'pileta' => $c_pileta,
                'patio' => $c_patio,
                'jardin' => $c_jardin
            )
        );

        $ubicacion = array(
            'calle' => $_POST['dir_calle'],
            'numero' => $_POST['dir_numero'],
            'localidad' => $_POST['localidad'],
        );

        $operacion = $_POST['operacion'];

        $prop = $p->newPropiedad($ubicacion, $dueño['id_cliente'], $reservado, $detalle, $operacion);
        $r = new Registro();
        $user = new Usuario();
        $user = $user->getUsuario($_SESSION['nombre']);
        $prop = $p->getPropiedad($prop);
        $loc = $prop['localidad'];
        $calle = $prop['calle'];
        $numero = $prop['numero'];
        $r->newRegistro("Nuevo propiedad creada - Direccion - $loc, $calle $numero",$user['id_usuario']);

        header('Location: propiedades');
        
    }

    $v->render();
?>