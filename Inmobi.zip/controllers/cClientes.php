<?php
    //controllers/..
    require '../fw/fw.php';
    require "../models/Ubicacion.php";
    require "../models/Usuario.php";
    require "../models/Registro.php";
    require '../models/Cliente.php';
    require '../models/Propiedad.php';
    require '../models/Estado.php';
    require '../models/Tipo.php';
    require '../views/vCliente.php';
    require '../views/vCrearCliente.php';
    require '../views/vClientes.php';

    if(!isset($_SESSION['logueado']))
    {
        header("Location: login");
        exit();
    }

    if(isset($_POST['cerrarSesion']))
    {
        unset($_SESSION['logueado']);
        unset($_SESSION['nombre']);
        header("Location: login");
        exit();
    }

    if(isset($_POST['prop']))
    {
        $id = $_POST['prop'];
        header("Location: propiedades-prop-$id", true);
    }

    if(isset($_POST['edit']))
    {
        $id = $_POST['edit'];
        header("Location: clientes-client-edit-$id");
    }

    $c = new Cliente();
    $ubicacion = new Ubicacion();

    if(isset($_POST['restaurar']))
    {
        $p = new Propiedad();
        $c->restaurar($_POST['restaurar']);
        $client = $c->getCliente($_POST['restaurar']);

        $p->restaurar_dueño($client["id_cliente"]);

        header("Location: clientes");
    }

    if(isset($_POST['borrar_id']))
    {
        $prop = new Propiedad();
        $propiedades = $prop->getTodos();
        foreach($propiedades as $p)
        {
            if($p['dueño'] == $_POST['borrar_id'])
                $prop->set_prop_inactivo($p['id_propiedad']);

        }
        $c->set_client_inactivo($_POST['borrar_id']);

        $r = new Registro();
        $user = new Usuario();
        $user = $user->getUsuario($_SESSION['nombre']);
        $client = $c->getClienteById($_POST['borrar_id']);
        $cuit = $client['cuit'];
        $r->newRegistro("Cliente borrado - CUIT - $cuit", $user['id_usuario']);

        header("Location: clientes");
    }

    if(!isset($_POST['nuevo_cliente']))
    {
        if(!isset($_POST['new']))
        {
            if(!isset($_GET['client']))
            {
                $v = new vClientes();
                $v->client = $c->getTodos();
                $v->prov = $ubicacion->getProvincias();

                if(isset($_POST['provincia']))
                    $v->prefProv = $_POST['provincia']; 
                else
                    $v->prefProv = 0;

                if(isset($_POST['tipo']))
                    $v->prefTipo = $_POST['tipo']; 
                else
                    $v->prefTipo = 0;
            }
            else{
                if($cl = $c->getCliente($_GET['client']))
                {
                    if(!$cl['activo'])
                    {
                        header("Location: clientes");
                    }
                    else
                    {
                        $v = new vCliente();
                    }
                        
                    $v->client = $cl;

                    $p = new Propiedad();
                    $v->prop = $p->getTodos();
                    
                    if($cl['id_tipo_cliente'] == 2)
                    {
                        $comp = new Comprador();
                        $v->pref = $comp->getComprador($cl['cuit']);
                    }
                    if($cl['id_tipo_cliente'] == 3)
                    {
                        $comp = new Vendedor_Comprador();
                        $v->pref = $comp->getVendedorComprador($cl['cuit']);
                    }
                    

                }
                else
                {
                    die("Cliente no encontrado");
                }
            }
        }
        else
        { 
            $v = new vCrearCliente();
            $location = new Ubicacion();
            $estado = new Estado();
            $tipo = new Tipo();
            $v->prov = $location->getProvincias();
            $v->loc = $location->getLocalidades();
            $v->cond = $estado->getEstados();
            $v->type = $tipo->getTipos(); 
            $v->client = $c->getTodos();
        }
    }
    else
    {
        //VALIDACIONES
        if(!isset($_POST['tipo_cliente'])) {die("Error datos faltantes"); exit;}
        if(!isset($_POST['nombre'])) {die("Error datos faltantes"); exit;}
        if(!isset($_POST['apellido'])) {die("Error datos faltantes"); exit;}
        if(!isset($_POST['cuit'])) {die("Error datos faltantes"); exit;}
        if(!isset($_POST['calle'])) {die("Error datos faltantes"); exit;}
        if(!isset($_POST['numero'])) {die("Error datos faltantes"); exit;}
        if(!isset($_POST['email'])) {die("Error datos faltantes"); exit;}
        if(!isset($_POST['telefono'])) {die("Error datos faltantes"); exit;}
        if(!isset($_POST['provincia'])) {die("Error datos faltantes"); exit;}
        if(!isset($_POST['localidad'])) {die("Error datos faltantes"); exit;}

        if($_POST['tipo_cliente'] > 1)
        {
            //VALIDACIONES
            if(!isset($_POST['pref_provincia'])) {die("Error datos faltantes"); exit;}
            if(!isset($_POST['pref_localidad'])) {die("Error datos faltantes"); exit;}
            if(!isset($_POST['pref_precio'])) {die("Error datos faltantes"); exit;}
            if(!isset($_POST['pref_estado'])) {die("Error datos faltantes"); exit;}
            if(!isset($_POST['pref_tipo'])) {die("Error datos faltantes"); exit;}

            $datos = array(
                'nombre' => $_POST['nombre'],
                'apellido' => $_POST['apellido'],
                'cuit' => $_POST['cuit'],
                'telefono' => $_POST['telefono'],
                'email' => $_POST['email'],
                'cuit' => $_POST['cuit'],
                'ubicacion' => array(
                    'localidad' => $_POST['localidad'],
                    'calle' => $_POST['calle'],
                    'numero' => $_POST['numero']
                ),
                'pref_provincia' => $_POST['pref_provincia'],
                'pref_localidad' => $_POST['pref_localidad'],
                'pref_precio' => $_POST['pref_precio'],
                'pref_estado' => $_POST['pref_estado'],
                'pref_tipo' => $_POST['pref_tipo'],
            );

            $c->newCliente($_POST['tipo_cliente'], $datos);
        }
        else
        {
            $datos = array(
                'nombre' => $_POST['nombre'],
                'apellido' => $_POST['apellido'],
                'cuit' => $_POST['cuit'],
                'telefono' => $_POST['telefono'],
                'email' => $_POST['email'],
                'cuit' => $_POST['cuit'],
                'ubicacion' => array(
                    'localidad' => $_POST['localidad'],
                    'calle' => $_POST['calle'],
                    'numero' => $_POST['numero']
                ));
            
            $c->newCliente($_POST['tipo_cliente'], $datos);
        }
        
        $r = new Registro();
        $user = new Usuario();
        $user = $user->getUsuario($_SESSION['nombre']);
        $c = $_POST['cuit'];
        $r->newRegistro("Nuevo cliente creado - CUIT - '$c'",$user['id_usuario']);
        
        header("Location: clientes");
    }

    $v->render();
?>