<?php
    //controllers/..
    require '../fw/fw.php';
    require '../models/Usuario.php';
    require '../views/vPropiedades.php';
    require '../views/vLogin1.php';
    require '../views/vLogin2.php';
    
    $u = new Usuario(); 

    if(count($_POST) > 0)
    {
        //VALIDACION
        if(!isset($_POST['user']))
        {
            $v = new vLogin1();
        }
        else
        {
            $dataUsuario = $u->getUsuario($_POST['user']);

            if((!isset($_POST['contraseña'])))
            {
                if($dataUsuario)
                {
                    $v = new vLogin2();
                    $v->user = $dataUsuario;
                }
                else
                {
                    $v = new vLogin1();
                }
            }
            else
            {
                if($usuario = $u->comprobar($_POST['user'], $_POST['contraseña']))
                {
                    $_SESSION['logueado'] = true;
                    $_SESSION['nombre'] = $usuario['nombre_usuario'];
                    $_SESSION['nivel'] = $dataUsuario['nivel'];
                    header("Location: propiedades");
                    exit();
                }
                else
                {
                    $v = new vLogin2();
                    $v->user = $dataUsuario;
                }
            }
        } 
    }
    else
    {
        if(isset($_SESSION['logueado']))
        {   if($_SESSION['logueado'])
                header("Location: propiedades");
            else 
                $v = new vLogin1();
        }
        else
        {
            $v = new vLogin1();
        }
    }

    $v->render();
?>
