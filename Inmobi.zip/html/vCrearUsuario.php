<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    
    <style>
    
    
 

/* Style inputs, select elements and textareas */
input[type=text], select, textarea{
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  resize: vertical;
}

/* Style the label to display next to the inputs */
label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

/* Style the submit button */
input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

/* Style the container */
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

/* Floating column for labels: 25% width */
.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

/* Floating column for inputs: 75% width */
.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}

</style>
    
    </style>
    <title>Crear Usuario </title>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">INMOBI</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="http://localhost/inmobi/propiedades">Propiedades</a></li>
      <li><a href="http://localhost/inmobi/clientes">Clientes</a></li>
      <?php if($_SESSION['nivel'] > 0) {?>
        <li class="active"><a href="http://localhost/inmobi/usuarios">Usuarios</a></li>
        <li><a href="http://localhost/inmobi/registros">Registros</a></li>
      <?php }?>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><form method="POST"><button type="submit" name="cerrarSesion" class="btn btn-danger boton"><span class="glyphicon glyphicon-user"></span> Cerrar sesion</button></form></li>
      
    </ul>
  </div>
</nav>
  <div class="container">
  <h1 style="text-align: center;"> CREAR NUEVO USUARIO </h1>
  <form method="POST" action="">
    <div class="row">
      <div class="col-25">
        <label for="fname">Nickname </label>
      </div>
      <div class="col-75">
        <input type="text" id="nickname" name="nickname" placeholder="Nombre de usuario.." minlength="4" maxlength="30">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="fname">Contraseña del usuario</label>
      </div>
      <div class="col-75">
        <input type="text" id="contraseña" name="contraseña" placeholder="Contraseña del usuario..." minlength="8" maxlength="40">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="fname">Confirmar contraseña</label>
      </div>
      <div class="col-75">
        <input type="text" id="confi_contraseña" name="contraseña" placeholder="Contraseña del usuario..." minlength="8" maxlength="40">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="fname">Nombre </label>
      </div>
      <div class="col-75">
        <input type="text" id="nombre" name="nombre" placeholder="Nombre..." minlength="4"  maxlength="200">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="fname">Apellido </label>
      </div>
      <div class="col-75">
        <input type="text" id="apellido" name="apellido" placeholder="Apellido..." minlength="4" maxlength="200">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="fname">Email </label>
      </div>
      <div class="col-75">
        <input type="text" id="email" name="email" placeholder="Email..." maxlength="100">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="fname">Telefono celular o de domicilio </label>
      </div>
      <div class="col-75">
        <input type="text" id="telefono" name="telefono" placeholder="Telefono..." minlength="8" maxlength="10">
      </div>
    </div>
    <div class="row">
      <div class="col-25">
        <label for="country">Nivel de permisos</label>
      </div>
      <div class="col-75">
        <select id="nivel" name="nivel">
          <option value="0">Usuario</option>
          <option value="1">Editor</option>
          <option value="2">Semi Admin.</option>
          <option value="3">Administrador</option>
        </select>
      </div>
    </div>

    <div class="row">
      <input type="submit" onclick="return validacion()" name="nuevo_usuario" value="Crear">
    </div>
  </form>
</div>
<script>
  function validacion()
  {
    usuarios = <?php echo json_encode($this->user); ?>;

    if(document.getElementById("nickname").value == "")
    {
      alert("Todo usuario debe tener un nickname");
      return false;
    }

    if(!/^\w+$/.test(document.getElementById("nickname").value))
    {
      alert("El nickname solo puede contener letras, numeros y _");
      return false;
    }

    for(var i = 0; i < usuarios.length; i++)
    {
      if(usuarios[i]["nombre_usuario"] == document.getElementById("nickname").value)
      {
        alert("El nickname ya se encuentra en uso");
        return false;
      }
    }

    if(document.getElementById("contraseña").value == "")
    {
      alert("Falta la contraseña");
      return false;
    }

    if(!/^\w+$/.test(document.getElementById("contraseña").value))
    {
      alert("La contraseña solo puede contener letras, numeros y _");
      return false;
    }

    if(document.getElementById("contraseña").value != document.getElementById("confi_contraseña").value)
    {
      alert("Las contraseñas no coinciden");
      return false;
    }

    if(document.getElementById("nombre").value == "")
    {
      alert("Todo usuario debe tener un nombre");
      return false;
    }

    if(!/^[a-zA-Z\s]+$/i.test(document.getElementById("nombre").value))
    {
      alert("El nombre no puede contener numeros");
      return false;
    }

    if(document.getElementById("apellido").value == "")
    {
      alert("Todo usuario debe tener un apellido");
      return false;
    }

    if(!/^[a-zA-Z\s]+$/i.test(document.getElementById("apellido").value))
    {
      alert("El apellido no puede contener numeros");
      return false;
    }

    if(document.getElementById("email").value == "")
    {
      alert("Todo cliente debe tener un email");
      return false;
    }

    if(!/^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i.test(document.getElementById("email").value))
    {
      alert("Email erroneo, ingreselo nuevamente");
      return false;
    }

    for(var i = 0; i < usuarios.length; i++)
    {
      if(usuarios[i]["email"] == document.getElementById("email").value)
      {
        alert("El email ya se encuentra en registrado");
        return false;
      }
    }

    if(document.getElementById("telefono").value == "")
    {
      alert("Todo usuario debe tener un telefono");
      return false;
    }

    if(!/^\d+$/.test(document.getElementById("telefono").value))
    {
      alert("El telefono no debe contener letras ni caracteres especiales");
      return false;
    }
    
    return true;
  }
</script>
</body>
</html>