<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    
    <style>
    body {
        background-color: gray    ;
       
}
    img{
      display: block;
      margin-right: auto;
      margin-left: auto;
      height: 250px;
      width: 250px;
      margin-top: 15px;
      margin-bottom:50px ;
    }

    .boton{
    margin-top: 6%;
    position: relative;
    right: 10px;
  }

.biografia{
  text-align:Center ;
  font-family: Arial;
  
  font-weight: 700;
  
  
}
.pepe {
  padding: 80px 120px;
}
.table-responsive ::-webkit-scrollbar{
  width: 7px;
  background-color:black;
}
.table-responsive ::-webkit-scrollbar-thumb{
  background-color:yellow;
  border-radius: 5px;
}
.table-responsive {
  max-height:300px;
  max-width:1000px;
  border: 3px ;
  border-style: solid;
  border-color: black;
  display: block;
  margin-right: auto;
  margin-left: auto;
  background-color: white;
}
</style>
    
    </style>
    <title>Cliente</title>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand">INMOBI</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="http://localhost/Inmobi/propiedades">Propiedades</a></li>
      <li class="active"><a href="http://localhost/Inmobi/clientes">Clientes</a></li>
      <?php if($_SESSION['nivel'] > 0) {?>
        <li><a href="http://localhost/inmobi/usuarios">Usuarios</a></li>
        <li><a href="http://localhost/inmobi/registros">Registros</a></li>
      <?php }?>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><form method="POST"><button type="submit" name="cerrarSesion" class="btn btn-danger boton"><span class="glyphicon glyphicon-user"></span> Cerrar sesion</button></form></li>
    </ul>
  </div>
</nav>

<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <h3>  <?= $this->client['nombre'] ?> <?= $this->client['apellido'] ?></h3>
      <img src="html/img/usuario.png" alt="Cara logo">
    </div>
    <div class="col-sm-4">
      <h1> INFORMACION </h1>
      <h4>Direccion: <?= $this->client['calle'] ?> <?= $this->client['numero'] ?></h4>
      <h4>Localidad: <?= $this->client['localidad'] ?> </h4>
      <h4>Telefono: <?= $this->client['telefono'] ?> </h4>
      <h4>Cuit: <?= $this->client['cuit'] ?> </h4>  
      <h4>Email: <?= $this->client['email'] ?> </h4>
    </div>
    <div class="col-sm-4">
      
      <img src="html/img/inmobi.jpg" class="img-thumbnail" alt="Cara empleado">
    </div>
  </div>
</div>
<?php if($this->client['id_tipo_cliente'] == 1 OR $this->client['id_tipo_cliente'] == 3)  {?>
  <div class="table-responsive">
    <h1>Propiedades a su nombre</h1>
    <table class="table ">
        <thead>
            <tr>
              <th>Direccion</th>
              <th>Precio</th>
              <th>Ubicacion</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach($this->prop as $p) {
        if($p['activo'] && ($p['dueño'] == $this->client['id_cliente'])){?>
        <tr>
          <td>
            <form method="POST">
              <button class="btn btn-primary btn-block" type="submit" name="prop" value="<?= $p['id_propiedad'] ?>"><?= $p['calle'] ?> <?= $p['numero'] ?> </button>
            </form>
          </td>
          <td> $<?= $p['precio'] ?> </td>
          <td> <?= $p['provincia'] ?>, <?= $p['localidad'] ?> </td> 
        </tr>
      <?php }
      }?>
      <tbody>
    </table>
  </div>
<?php }?>
     
<?php if($this->client['id_tipo_cliente'] == 2 OR $this->client['id_tipo_cliente'] == 3)  {?>
  <div class="table-responsive">
    <h1>Posibles propiedades de interes</h1>
    <table class="table ">
      <thead>
          <tr>
            <th>Direccion</th>
            <th>Precio</th>
            <th>Ubicacion</th>
          </tr>
      </thead>
      <tbody>
          <?php foreach($this->prop as $p) {
            if($p['activo'] && ($p['precio'] <= $this->pref['precio']) && ($p['estado'] == $this->pref['estado'])
              && ($p['tipo'] == $this->pref['tipo']) && ($p['localidad'] == $this->pref['localidad'])){?>
            <tr>
              <td>
                <form method="POST">
                  <button class="btn btn-primary btn-block" type="submit" name="prop" value="<?= $p['id_propiedad'] ?>"><?= $p['calle'] ?> <?= $p['numero'] ?> </button>
                </form>
              </td>
              <td> $<?= $p['precio'] ?> </td>
              <td> <?= $p['provincia'] ?>, <?= $p['localidad'] ?> </td> 
            </tr>
          <?php }
          }?>
      <tbody>
    </table>
  </div>
<?php }
  ?>     
      
   
  



   



   
</body>
</html>

      