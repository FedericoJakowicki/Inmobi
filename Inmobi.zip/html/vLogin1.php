<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"  href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">  
  <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> -->
    <title>Document</title>
</head>
<body>  
<div class="container">
<img src="controllers/img/inmobi.jpg"  alt="Inmobi"   class="center">
<form class="form-horizontal center" method="Post">
  <div class="form-group center">
    <label class="control-label col-sm-2 center" for="email">Usuario :</label>
    <div class="col-sm-10 center">
      <input type="text" class="form-control center"  name="user" placeholder="Ingrese su email o nombre de usuario">
    </div>
  </div>
  <div class="form-group center">
    <div class="col-sm-offset-2 col-sm-10 center">
      <div class="checkbox">
        <label><input type="checkbox"> Recordarme</label>
      </div>
    </div>
  </div>
  <div class="form-group center">
    <div class="col-sm-offset-2 col-sm-10 center">
      <button type="submit"  class="btn btn-success">Ingresar</button>
      
    </div>
  </div>
</form>
</div>
</body>
</html>
<style>
.center{
   
  display: block;
  margin-left: auto;
  margin-right: auto;
  text-align: center;
  

}
body {
  background-image: url("controllers/img/insta.jpg");

  

  /* Full height */
  height: 100%;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
img{
   
   display: block;
    margin-right: auto;
    margin-left: auto;
    
    
    height: 250px;
    width: 250px;
    margin-top: 50px;
    margin-bottom:50px ;
}
</style>
