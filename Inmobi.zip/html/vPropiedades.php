<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

  <style>
    input[type=text] {
    width: 75%;
    text-align: center;
      
    }

    .boton{
      margin-top: 6%;
      position: relative;
      right: 10px;
    }

    .container input {
    display: block;
    width: 75%;
    clear: both;
    margin-top: 50px;
    margin-left: auto;
    margin-right: auto;
    }

    .pepe{
    display: block;
    margin-right: 20%;
    margin-left: 20%;
    }

    .buscar{
    display: block;
    margin-right: auto;
    margin-left: 500px;
    margin-bottom: 20px;
    }

    .texto{
    text-align: center;
    margin-top: auto;
    }

  </style>

  <title>Propiedades</title>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand">INMOBI</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="http://localhost/Inmobi/propiedades">Propiedades</a></li>
      <li><a href="http://localhost/Inmobi/clientes">Clientes</a></li>
      <?php if($_SESSION['nivel'] > 0) {?>
        <li><a href="http://localhost/inmobi/usuarios">Usuarios</a></li>
        <li><a href="http://localhost/inmobi/registros">Registros</a></li>
      <?php }?>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><form method="POST"><button type="submit" name="cerrarSesion" class="btn btn-danger boton"><span class="glyphicon glyphicon-user"></span> Cerrar sesion</button></form></li>
      
    </ul>
  </div>
</nav>

<form class="form-inline buscar" action="" method="POST">
      <label for="operacion" style="margin-left: 10px;">Operacion</label>
      <select id="operacion" name="operacion">
          <option name="tipo" value="0"> Cualquiera </option>
          <option name="tipo" value="1"> Venta </option>
          <option name="tipo" value="2"> Alquiler </option>
          <option name="tipo" value="3"> Venta/Alquiler </option>
      </select>

      <label for="provincia" style="margin-left: 10px;">Provincia</label>
      <select id="Provincia" name="provincia">
        <option name="tipo" value="0"> Cualquiera </option>
        <?php foreach($this->prov as $p) {?>
          <option name="tipo" value=<?= $p['id_provincia']?>> <?= $p['provincia']?> </option>
        <?php }?>
      </select>

      <button type="submit" style="margin-left: 10px;" class="btn btn-default">Filtrar</button>
</form>

<div class="container">
  <form method="POST" style="margin-bottom: 25px;">
    <?php if($_SESSION['nivel'] > 0) {?>
      <button type="submit" class="btn btn-primary btn-block" name="new">Nueva Propiedad</button>
    <?php }?>
  </form>          
  <table class="table table-condensed">
    <thead>
   
      <tr>
        <th class="texto">Direccion</th>
        <th class="texto">Tipo de Operacion</th>
        <th class="texto">Precio</th>
        <th class="texto">Ubicacion</th>
        <?php if($_SESSION['nivel'] > 0) {?>
          <th class="texto">Eliminar</th>
        <?php }?>
      </tr>
      
    </thead>
    <tbody class="texto">
      <?php foreach($this->prop as $p) {
        if($p['activo']){
          if($this->prefProv == 0 && $this->prefOp == 0){?>
          <tr>
            <td>
              <form method="GET">
                <button type="submit" class="btn btn-primary btn-block" name="prop" value="<?= $p['id_propiedad'] ?>"><?= $p['calle'] ?> <?= $p['numero'] ?> </button>
              </form>
            </td>
            <td><?= $p['operacion'] ?> </td>
            <td>$<?= $p['precio'] ?> </td>
            <td><?= $p['provincia'] ?>, <?= $p['localidad'] ?> </td> 
            <?php if($_SESSION['nivel'] > 0) {?>
              <td>
                <form method="POST">
                  <button id="form_borrar" onclick="return confirmacion('Desea realmente borrar esta propiedad?');" type="submit" name="borrar_id" value="<?= $p['id_propiedad']?>" class="btn btn-danger">Borrar</button>
                </form> 
              </td>
            <?php }?>
          </tr>
      <?php }
        if($this->prefProv == 0 && $this->prefOp != 0){
          if($this->prefOp == $p['id_operacion']){?>
          <tr>
            <td>
              <form method="GET">
                <button type="submit" class="btn btn-primary btn-block" name="prop" value="<?= $p['id_propiedad'] ?>"><?= $p['calle'] ?> <?= $p['numero'] ?> </button>
              </form>
            </td>
            <td><?= $p['operacion'] ?> </td>
            <td>$<?= $p['precio'] ?> </td>
            <td><?= $p['provincia'] ?>, <?= $p['localidad'] ?> </td> 
            <?php if($_SESSION['nivel'] > 0) {?>
              <td>
                <form method="POST">
                  <button id="form_borrar" onclick="return confirmacion('Desea realmente borrar esta propiedad?');" type="submit" name="borrar_id" value="<?= $p['id_propiedad']?>" class="btn btn-danger">Borrar</button>
                </form> 
              </td>
            <?php }?>
          </tr>
      <?php }
        } 
        if($this->prefOp == 0 && $this->prefProv != 0){
          if($this->prefProv == $p['id_provincia']){?>
          <tr>
            <td>
              <form method="GET">
                <button type="submit" class="btn btn-primary btn-block" name="prop" value="<?= $p['id_propiedad'] ?>"><?= $p['calle'] ?> <?= $p['numero'] ?> </button>
              </form>
            </td>
            <td><?= $p['operacion'] ?> </td>
            <td>$<?= $p['precio'] ?> </td>
            <td><?= $p['provincia'] ?>, <?= $p['localidad'] ?> </td> 
            <?php if($_SESSION['nivel'] > 0) {?>
              <td>
                <form method="POST">
                  <button id="form_borrar" onclick="return confirmacion('Desea realmente borrar esta propiedad?');" type="submit" name="borrar_id" value="<?= $p['id_propiedad']?>" class="btn btn-danger">Borrar</button>
                </form> 
              </td>
            <?php }?>
          </tr>
        <?php }
        }
        if($this->prefOp != 0 && $this->prefProv != 0){
          if($this->prefProv == $p['id_provincia'] && $this->prefOp == $p['id_operacion']){?>
          <tr>
            <td>
              <form method="GET">
                <button type="submit" class="btn btn-primary btn-block" name="prop" value="<?= $p['id_propiedad'] ?>"><?= $p['calle'] ?> <?= $p['numero'] ?> </button>
              </form>
            </td>
            <td><?= $p['operacion'] ?> </td>
            <td>$<?= $p['precio'] ?> </td>
            <td><?= $p['provincia'] ?>, <?= $p['localidad'] ?> </td> 
            <?php if($_SESSION['nivel'] > 0) {?>
              <td>
                <form method="POST">
                  <button id="form_borrar" onclick="return confirmacion('Desea realmente borrar esta propiedad?');" type="submit" name="borrar_id" value="<?= $p['id_propiedad']?>" class="btn btn-danger">Borrar</button>
                </form> 
              </td>
            <?php }?>
          </tr>
      <?php }
        }
      }
    }?>
    </tbody>
  </table>
</div>
<script src="html/js/general.js"></script>
</body>
</html>