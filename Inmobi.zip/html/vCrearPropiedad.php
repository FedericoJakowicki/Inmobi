<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    
    <style>
    
    
 

/* Style inputs, select elements and textareas */
input[type=text], select, textarea{
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  resize: vertical;
}

.form{
  display: inline-block;
}

/* Style the label to display next to the inputs */
label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

/* Style the submit button */
input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

/* Style the container */
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

/* Floating column for labels: 25% width */
.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

/* Floating column for inputs: 75% width */
.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}

</style>
    
    </style>
    <title>Crear Propiedad </title>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand">INMOBI</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="http://localhost/inmobi/propiedades">Propiedades</a></li>
      <li><a href="http://localhost/inmobi/clientes">Clientes</a></li>
      <?php if($_SESSION['nivel'] > 0) {?>
        <li><a href="http://localhost/inmobi/usuarios">Usuarios</a></li>
        <li><a href="http://localhost/inmobi/registros">Registros</a></li>
      <?php }?>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><form method="POST"><button type="submit" name="cerrarSesion" class="btn btn-danger boton"><span class="glyphicon glyphicon-user"></span> Cerrar sesion</button></form></li>
      
    </ul>
  </div>
</nav>

  <div class="container">
  <h1> CREAR PROPIEDAD </h1>
  <form method="POST" action="">
    <div class="row" >
      <div class="col-25">
        <label for="fname">Calle</label>
      </div>
      <div class="col-75">
        <input type="text" id="calle" name="dir_calle" minlength="4" placeholder="Calle de la propiedad...">
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="country">Numero</label>
      </div>
      <div class="col-75">
        <input type="number" id="numero" name="dir_numero" >
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="lname">Reservado</label>
      </div>
      <div class="checkbox">
    <label><input type="checkbox" name="reservado"> Deje la tilde puesta si esta reservada</label>
     </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="country">Cuit del dueño</label>
      </div>
      <div class="col-75">
        <input type="text" id="cuit" name="dueño" placeholder="Ingrese cuit del dueño sin (-)..." maxlength="11">
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="subject">Descripcion de la casa</label>
      </div>
      <div class="col-75">
        <textarea id="descripcion" name="descripcion" placeholder="No mas de 2000 caracteres" style="height:200px" maxlength="2000"></textarea>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="fname">Provincias</label>
      </div>
      <div class="col-75">                      
        <select id="prov" name="provincia" onchange="changeLocation('prov', 'loc')">
          <option name="tipo" value="0">Elige una provincia...</option>
          <?php foreach($this->prov as $p) {?>
            <option name="tipo" value="<?= $p['id_provincia']?>"> <?= $p['provincia']?> </option>
          <?php }?>
        </select>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="fname">Localidad</label>
      </div>
      <div class="col-75">       
        <select id="loc" name="localidad">
        </select>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="country">Tipo de operacion</label>
      </div>
      <div class="col-75">
        <select id="operacion" name="operacion">
          <option value="0">Seleccione un tipo de operacion...</option> 
          <option value="1">Venta</option> 
          <option value="2">Alquiler</option>
          <option value="3">Alquiler y Venta</option>
        </select>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="fname">Precio</label>
      </div>
      <div class="col-75">
        <input type="text" id="precio" name="precio" placeholder="Ingrese el precio">
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="fname">Muebles</label>
      </div>
      <div class="checkbox">
         <label><input type="checkbox" name="muebles"> Deje la tilde puesta si esta amueblada</label>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="country">Estado</label>
      </div>
      <div class="col-75">
        <select id="estado" name="estado">
        <option value="0">Seleccione un estado...</option> 
          <?php foreach($this->cond as $c) {?>
              <option name="tipo" value="<?= $c['id_estado']?>"> <?= $c['estado']?> </option>
          <?php }?>
        </select>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="fname">Terraza</label>
      </div>
      <div class="checkbox">
         <label><input type="checkbox" name="c_terraza"> Deje la tilde puesta si tiene terraza</label>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="fname">Garage</label>
      </div>
      <div class="checkbox">
         <label><input type="checkbox" name="c_garage"> Deje la tilde puesta si tiene garagea</label>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="fname">Balcon</label>
      </div>
      <div class="checkbox">
         <label><input type="checkbox" name="c_balcon"> Deje la tilde puesta si tiene balcon</label>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="fname">Pileta</label>
      </div>
      <div class="checkbox">
         <label><input type="checkbox" name="c_pileta"> Deje la tilde puesta si tiene pileta</label>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="fname">Patio</label>
      </div>
      <div class="checkbox">
         <label><input type="checkbox" name="c_patio"> Deje la tilde puesta si tiene patio</label>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="fname">Jardin Frontal</label>
      </div>
      <div class="checkbox">
         <label><input type="checkbox" name="c_jardin"> Deje la tilde puesta si tiene jardin</label>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="country">Cantidad de baños</label>
      </div>
      <div class="col-75">
        <select id="baños" name="baños">
          <option value="0">Seleccione la cantidad de baños...</option> 
          <option value="1">1</option> 
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5 o +</option>
        </select>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="country">Cantidad de habitaciones</label>
      </div>
        
      <div class="col-75">
        <input type="number" min="1" max="20" id="habitaciones" name="habitaciones" >
      </div>
    </div>
    
    <div class="row">
      <div class="col-25">
        <label for="country">Tipo de casa</label>
      </div>
      <div class="col-75">
        <select id="tipo" name="tipo">
          <option value="0">Seleccione la tipo de casa...</option> 
          <?php foreach($this->type as $t) {?>
              <option name="tipo" value="<?= $t['id_tipo']?>"> <?= $t['tipo']?> </option>
          <?php }?>
        </select>
      </div>
    </div>

    <div class="row">
      <div class="col-25">
        <label for="fname">Tamaño:</label>
      </div>
      <div class="col-75">
        <input type="number" id="tamaño" name="tamaño" placeholder="Ingrese el numero en mts2...">
      </div>
    </div>

    <div class="row">
      <input type="submit" name="nueva_propiedad" onclick="return validacion()" value="Crear">
      <form class="form" method="POST" name="cancelar"><button class="btn btn-success">Cancelar</button></form>
    </div>
  </form>
</div>
<script>
  function changeLocation(prov_id, loc_id)
  {
    array_loc = <?php echo json_encode($this->loc); ?>;
    var prov = document.getElementById(prov_id);
    var loc = document.getElementById(loc_id);
    var valid = [];
    var opcion = prov.options[prov.options.selectedIndex].value;

    while(loc.firstChild){
      loc.removeChild(loc.lastChild);
    }

    for(var i = 0; i < array_loc.length; i++)
    {
      if(array_loc[i]["provincia"] == opcion)
        valid.push(array_loc[i]) 
    }

    for(var i = 0; i < valid.length; i++)
    {
      newLoc = document.createElement("option");
      newLoc.value = valid[i]["id_localidad"];
      newLoc.text = valid[i]["localidad"];
      loc.appendChild(newLoc);
    }      
  }

  function validacion()
  {
    if(document.getElementById("calle").value == 0)
    {
      alert("El campo calle no puede estar vacio");
      return false;
    }

    if(!/^[a-zA-Z\s]+$/i.test(document.getElementById("calle").value))
    {
      alert("La calle no puede contener numeros ni caracteres especiales");
      return false;
    }

    if(document.getElementById("numero").value == "")
    {
      alert("El campo numero no puede estar vacio");
      return false;
    }

    if(document.getElementById("cuit").value == "")
    {
      alert("Todo dueño debe tener un CUIT");
      return false;
    }

    if(!cuit_validation(document.getElementById("cuit").value))
    {
      alert("El CUIT es erroneo, ingreselo nuevamente");
      return false;
    }

    if(!buscar_cuit(document.getElementById("cuit").value))
    {
      alert("El CUIT no pertenece a un dueño o no existe, ingreselo nuevamente");
      return false;
    }

    if(document.getElementById("descripcion").value == "")
    {
      alert("El campo descripcion no puede estar vacio");
      return false;
    }

    if(document.getElementById("prov").value == 0)
    {
      alert("Debe seleccionar una provincia");
      return false;
    }

    if(document.getElementById("operacion").value == 0)
    {
      alert("Debe seleccionar una tipo de operacion");
      return false;
    }

    if(document.getElementById("precio").value == "")
    {
      alert("El precio no puede estar vacio");
      return false;
    }

    if(!/^\d+$/.test(document.getElementById("precio").value))
    {
      alert("El precio no puede contener letras ni caracteres especiales");
      return false;
    }

    if(document.getElementById("estado").value == 0)
    {
      alert("Debe seleccionar una estado");
      return false;
    }
    
    if(document.getElementById("baños").value == 0)
    {
      alert("Debe seleccionar una cantidad de baños");
      return false;
    }

    if(document.getElementById("habitaciones").value == "")
    {
      alert("El campo habitaciones no puede estar vacio");
      return false;
    }

    if(document.getElementById("tipo").value == 0)
    {
      alert("Debe seleccionar un tipo de casa");
      return false;
    }

    if(document.getElementById("tamaño").value == "")
    {
      alert("El campo tamaño no puede estar vacio");
      return false;
    }

    return true;
  }

  function buscar_cuit(cuit)
  {
    clients = <?php echo json_encode($this->clients); ?>;
  
    for(var i = 0; i < clients.length; i++)
    {
      if(clients[i]["cuit"] == cuit && clients[i]["activo"])
        return true;
    }

    return false;
  }

  function cuit_validation(cuit)
  {
    inputString = cuit.toString()
    if (inputString.length == 11) {
        var Caracters_1_2 = inputString.charAt(0) + inputString.charAt(1)
        if (Caracters_1_2 == "20" || Caracters_1_2 == "23" || Caracters_1_2 == "24" || Caracters_1_2 == "27" || Caracters_1_2 == "30" || Caracters_1_2 == "33" || Caracters_1_2 == "34") {
            var Count = inputString.charAt(0) * 5 + inputString.charAt(1) * 4 + inputString.charAt(2) * 3 + 
                        inputString.charAt(3) * 2 + inputString.charAt(4) * 7 + inputString.charAt(5) * 6 + 
                        inputString.charAt(6) * 5 + inputString.charAt(7) * 4 + inputString.charAt(8) * 3 + 
                        inputString.charAt(9) * 2 + inputString.charAt(10) * 1;
            Division = Count / 11;
            if (Division == Math.floor(Division)) {
                return true
            }
        }
    }
    return false
  }
</script>
</body>
</html>