<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?famiy=Open+Sans|Oswald">
    
    <style>
    body {
        background-color: gray    ;
       
}
    img{
      height: 350px;
      width: 350px;
      margin-top: 15px;
    }

    .boton{
    margin-top: 6%;
    position: relative;
    right: 10px;
  }

.biografia{
  text-align:Center ;
  font-family: Arial;
  
  font-weight: 700;
  
  
}
.pepe {
  padding: 80px 120px;
}
.table ::-webkit-scrollbar{
  width: 7px;
  background-color:black;
}
.table ::-webkit-scrollbar-thumb{
  background-color:yellow;
  border-radius: 5px;
}
.table-responsive {
    max-height:450px;
    width:900x;
    background-color: white;
}
</style>
    
    </style>
    <title>Propiedad</title>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand">INMOBI</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active"><a href="http://localhost/Inmobi/propiedades">Propiedades</a></li>
      <li><a href="http://localhost/Inmobi/clientes">Clientes</a></li>
      <?php if($_SESSION['nivel'] > 0) {?>
        <li><a href="http://localhost/inmobi/usuarios">Usuarios</a></li>
        <li><a href="http://localhost/inmobi/registros">Registros</a></li>
      <?php }?>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><form method="POST"><button type="submit" name="cerrarSesion" class="btn btn-danger boton"><span class="glyphicon glyphicon-user"></span> Cerrar sesion</button></form></li>
      
    </ul>
  </div>
</nav>

<div class="container">
  <div class="row">
    <div class="col-sm-4">
      <img src="html/img/inmobi.jpg" class="img-thumbnail" alt="Cara empleado">
      <h1> INFORMACION </h1>
      <h4>Provincia: <?= $this->prop['provincia'] ?> </h4>
      <h4>Localidad: <?= $this->prop['localidad'] ?> </h4>
      <h4>Direccion: <?= $this->prop['calle'] ?> <?= $this->prop['numero'] ?> </h4>
      <h4>Reservado: <?php if($this->prop['reservado']) echo("Si"); else echo("No"); ?> </h4>
      <h4>Tipo de Operacion: <?= $this->prop['operacion'] ?> </h4>
      <h4>Habitaciones: <?= $this->prop['habitaciones'] ?> </h4>
      <h4>Baños: <?= $this->prop['baños'] ?> </h4>
      <h4>Amueblada: <?php if($this->prop['muebles']) echo("Si"); else echo("No"); ?> </h4>
      <h4>Terraza: <?php if($this->prop['terraza']) echo("Si"); else echo("No"); ?> </h4>
      <h4>Garage: <?php if($this->prop['garage']) echo("Si"); else echo("No"); ?> </h4>
      <h4>Balcon: <?php if($this->prop['balcon']) echo("Si"); else echo("No"); ?> </h4>
      <h4>Pileta: <?php if($this->prop['pileta']) echo("Si"); else echo("No"); ?> </h4>
      <h4>Patio: <?php if($this->prop['patio']) echo("Si"); else echo("No"); ?> </h4>
      <h4>Jardin: <?php if($this->prop['jardin']) echo("Si"); else echo("No"); ?> </h4>
      <h4>Tamaño: <?= $this->prop['tamaño'] ?> Mts2 </h4>
      <h4>Estado: <?= $this->prop['estado'] ?></h4>
      <h4>Precio: $<?= $this->prop['precio'] ?> </h4>
    </div>
    <div class="col-sm-8">
   <h1> <h3><?= $this->prop['tipo'] ?>, <?= $this->prop['calle'] ?> <?= $this->prop['numero'] ?></h3> </h1>
     <h2>Descripcion</h2>
     <p><?= $this->prop['descripcion'] ?></p>
   <h2>Posibles compradores</h2>          
  <div class="table-responsive">
  <table class="table" >
    <thead>
      <tr>
        <th>Cliente</th>
        <th>Correo</th>
        <th>Numero</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($this->comprador as $c) {
        if($c['activo'] && ($this->prop['localidad'] == $c['localidad']) && ($this->prop['tipo'] == $c['tipo']) && 
        ($this->prop['estado'] == $c['estado']) && ($this->prop['precio'] <= $c['precio'])) {?>
          <tr>
            <td>
            <form method="POST">
              <button type="submit" class="btn btn-primary btn-block" name="client" value="<?= $c['cuit'] ?>"><?= $c['nombre'] ?> <?= $c['apellido'] ?></button>
            </form>
            </td>
            <td><?= $c['email'] ?></td>
            <td><?= $c['telefono'] ?></td>
          </tr>
        <?php }
      }?>
    </tbody>
  </table>
  </div>
  </div>
</div>
</div>

</body>
</html>

