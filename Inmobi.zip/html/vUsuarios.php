<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    
    <style>
    
    
  input[type=text] {
    width: 75%;
    text-align: center;
    
}
.container input {
  display: block;
  width: 75%;
  clear: both;
  margin-top: 50px;
  margin-left: auto;
  margin-right: auto;
}

.pepe{
  display: block;
  margin-right: 20%;
  margin-left: 20%;
  

}

.texto{
  text-align: center;
}

.logged{
  background-color: grey;
  color: white;
}

.selected{
  background-color: red;
  color: white;
}

</style>
    
    </style>
    <title>Usuarios</title>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand">INMOBI</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="http://localhost/Inmobi/propiedades">Propiedades </a></li>
      <li><a href="http://localhost/Inmobi/clientes">Clientes </a></li>
      <?php if($_SESSION['nivel'] > 0) {?>
        <li class="active"><a href="http://localhost/inmobi/usuarios">Usuarios</a></li>
        <li><a href="http://localhost/inmobi/registros">Registros</a></li>
      <?php }?>
      
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><form method="POST"><button type="submit" name="cerrarSesion" class="btn btn-danger boton"><span class="glyphicon glyphicon-user"></span> Cerrar sesion</button></form></li>

    </ul>
  </div>
</nav>
<div class="fondo-barra">

<div class="container">
<?php if($_SESSION['nivel'] > 1) {?>
  <form method="POST">
    <button type="submit" name="new" class="btn btn-primary btn-block" >Nuevo Usuario</button> 
  </form>
<?php }?>
  <table class="table table-condensed ">
    <thead>
   
      <tr>
        <th class="texto">Nombre y Apellido</th>
        <th class="texto">Email</th>
        <th class="texto">Telefono</th>
        <th class="texto">Tipo de Usuario</th>
        <?php if($_SESSION['nivel'] > 1) {?>
              <th class="texto">Eliminar</th>
          <?php }?>
        
        
      </tr>
      
    </thead>
    <tbody>
    
      
      <?php foreach($this->user as $u) {
        if($u['activo']) {?>
      <tr <?php if($u['nombre_usuario'] == $_SESSION['nombre'] && 
      $this->selected != $u['id_usuario']) {?> class="logged" <?php }?>
      <?php if($this->selected == $u['id_usuario']) {?> class="selected" <?php }?>>  
          
          <td class="texto">  <?= $u['nombre'] ?> <?= $u['apellido'] ?></td>
          <td class="texto"> <?= $u['email'] ?> </td>
          <td class="texto"> <?= $u['telefono'] ?> </td>
          <?php if($u['nivel'] == 0) {?>
              <td class="texto"> Usuario</td>
          <?php }?>
          <?php if($u['nivel'] == 1) {?>
              <td class="texto"> Editor</td>
          <?php }?>
          <?php if($u['nivel'] == 2) {?>
              <td class="texto"> Semi Admin.</td>
          <?php }?>
          <?php if($u['nivel'] == 3) {?>
              <td class="texto"> Administrador</td>
          <?php }?>
          <?php if($_SESSION['nivel'] > 1 && $u['nivel'] < 3 && $u['nombre_usuario'] != $_SESSION['nombre']) {?>
            <form method="POST">
              <td class="texto"> <button type="submmit" onclick="confirmacion('Realmente desae borrar este usuario?')" name="borrar_usuario" value="<?= $u['nombre_usuario'] ?>" class="btn-danger">Borrar</button></td>
            </form>
          <?php } ?>
          <?php if($_SESSION['nivel'] < 2 || $u['nivel'] > 2 && $u['nombre_usuario'] == $_SESSION['nombre']) {?>
              <td></td>
          <?php } ?>
          
        </tr>
      <?php }
    } ?>
      
      
    </tbody>
  </table>
  
</div>
<script src="html/js/general.js"></script>
</body>
</html>