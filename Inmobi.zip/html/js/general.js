function confirmacion(mensaje)
{
    if(!confirm(mensaje))
        return false;
    
    return true;
}