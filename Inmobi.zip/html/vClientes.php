<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    
    <style>
    
    
  input{
    width: 120px;
    text-align: center;
    
}

.container input {
  display: block;
  width: 75%;
  clear: both;
  margin-top: 50px;
  margin-left: auto;
  margin-right: auto;
}

.pepe{
  display: block;
  margin-right: 20%;
  margin-left: 20%;
}

.boton{
    margin-top: 6%;
    position: relative;
    right: 10px;
  }

  .buscar{
    display: block;
    margin-right: auto;
    margin-left: 450px;
    margin-bottom: 20px;
    }

    .cuit{
    display: block;
    margin-right: auto;
    margin-left: 575px;
    margin-bottom: 20px;
    }

    .restaurar{
    display: block;
    margin-right: auto;
    margin-left: 525px;
    margin-bottom: 20px;
    }

.texto{
  text-align: center;
  margin-top: auto;
  }

</style>
    
    </style>
    <title>Clientes</title>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand">INMOBI</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="http://localhost/Inmobi/propiedades">Propiedades</a></li>
      <li class="active"><a href="http://localhost/Inmobi/clientes">Clientes</a></li>
      <?php if($_SESSION['nivel'] > 0) {?>
        <li><a href="http://localhost/inmobi/usuarios">Usuarios</a></li>
        <li><a href="http://localhost/inmobi/registros">Registros</a></li>
      <?php }?>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><form method="POST"><button type="submit" name="cerrarSesion" class="btn btn-danger boton"><span class="glyphicon glyphicon-user"></span> Cerrar sesion</button></form></li>
      
    </ul>
  </div>
</nav>

<form class="form-inline buscar" action="" method="POST">
  <label for="tipo" style="margin-left: 10px;">Tipo de Cliente</label>
  <select id="tipo" name="tipo">
      <option name="tipo" value="0"> Cualquiera </option>
      <option name="tipo" value="1"> Vendedor </option>
      <option name="tipo" value="2"> Comprador </option>
      <option name="tipo" value="3"> Vendedro / Comprador </option>
  </select>

  <label for="provincia" style="margin-left: 10px;">Provincia</label>
  <select id="Provincia" name="provincia">
    <option name="tipo" value="0"> Cualquiera </option>
    <?php foreach($this->prov as $p) {?>
      <option name="tipo" value=<?= $p['id_provincia']?>> <?= $p['provincia']?> </option>
    <?php }?>
  </select>

  <button type="submit" style="margin-left: 10px;" class="btn btn-default">Filtrar</button>
</form>

<form class="form-inline cuit" action="" method="GET">
  <label for="tipo" style="margin-left: 10px;">CUIT</label>
  
  <input id="cuit" name="client" placeholder="Ingrese el CUIT..." maxlength="11" minlength="11"></input>
  
  <button type="submit" onclick="return busqueda('cuit')" style="margin-left: 10px;" class="btn btn-default">Buscar</button>
</form>

<?php if($_SESSION['nivel'] > 0) {?>
  <form class="form-inline restaurar" action="" method="POST">
    <label for="tipo" style="margin-left: 10px;">Restaurar Cliente por CUIT</label>
    
    <input id="cuit_restaurar" name="restaurar" placeholder="Ingrese el CUIT..." maxlength="11" minlength="11"></input>
    
    <button type="submit" onclick="return restaurar_cliente('cuit_restaurar')" style="margin-left: 10px;" class="btn btn-default">Restaurar</button>
  </form>
<?php } ?>

<div class="container">
  <form method="POST">
    <?php if($_SESSION['nivel'] > 0) {?>
      <button type="submit" class="btn btn-primary btn-block" name="new">Nuevo Cliente</button>
    <?php }?>
  </form>     
  <table class="table table-condensed ">
    <thead>
   
      <tr>
        <th class="texto">Cliente</th>
        <th class="texto">Ubicacion</th>
        <th class="texto">Tipo de Cliente</th>
        <th class="texto">Telefono</th>
        <th class="texto">Cuit</th>
        <th class="texto">Email</th>
        <?php if($_SESSION['nivel'] > 0) {?>
          <th class="texto">Eliminar</th>
        <?php }?>
      </tr>
      
    </thead>
    <tbody>
      <?php foreach($this->client as $c) {
        if($c['activo']) {
          if($this->prefProv == 0 && $this->prefTipo == 0){?>
            <tr class="texto">  
              <td><form method="GET"><button type="submit" class="btn btn-primary btn-block" name="client" value="<?= $c['cuit'] ?>"><span class="glyphicon glyphicon-user icono"></span> <?= $c['nombre'] ?> <?= $c['apellido'] ?> </button></form></td>
              <td> <?= $c['provincia'] ?>, <?= $c['localidad'] ?> </td> 
              <td> <?= $c['tipo_cliente'] ?> </td> 
              <td> <?= $c['telefono'] ?> </td> 
              <td> <?= $c['cuit'] ?> </td>
              <td> <?= $c['email'] ?> </td>
              <?php if($_SESSION['nivel'] > 0) {?>
              <td>
                <form method="POST">
                  <button id="form_borrar" onclick="return confirmacion('Desea realmente borrar este cliente?');" type="submit" name="borrar_id" value="<?= $c['id_cliente']?>" class="btn btn-danger">Borrar</button>
                </form> 
              </td>
              <?php } ?>
            </tr>
      <?php }
          if($this->prefProv != 0 && $this->prefTipo == 0 && ($this->prefProv == $c["id_provincia"])){?>
            <tr class="texto">  
              <td><form method="GET"><button type="submit" class="btn btn-primary btn-block" name="client" value="<?= $c['cuit'] ?>"><span class="glyphicon glyphicon-user icono"></span> <?= $c['nombre'] ?> <?= $c['apellido'] ?> </button></form></td>
              <td> <?= $c['provincia'] ?>, <?= $c['localidad'] ?> </td>
              <td> <?= $c['tipo_cliente'] ?> </td> 
              <td> <?= $c['telefono'] ?> </td> 
              <td> <?= $c['cuit'] ?> </td>
              <td> <?= $c['email'] ?> </td>
              <?php if($_SESSION['nivel'] > 0) {?>
              <td>
                <form method="POST">
                  <button id="form_borrar" onclick="return confirmacion('Desea realmente borrar este cliente?');" type="submit" name="borrar_id" value="<?= $c['id_cliente']?>" class="btn btn-danger">Borrar</button>
                </form> 
              </td>
              <?php } ?>
            </tr>
        <?php }
          if($this->prefProv == 0 && $this->prefTipo != 0 && ($this->prefTipo == $c["id_tipo_cliente"])){?>
            <tr class="texto">  
              <td><form method="GET"><button type="submit" class="btn btn-primary btn-block" name="client" value="<?= $c['cuit'] ?>"><span class="glyphicon glyphicon-user icono"></span> <?= $c['nombre'] ?> <?= $c['apellido'] ?> </button></form></td>
              <td> <?= $c['provincia'] ?>, <?= $c['localidad'] ?> </td>
              <td> <?= $c['tipo_cliente'] ?> </td> 
              <td> <?= $c['telefono'] ?> </td> 
              <td> <?= $c['cuit'] ?> </td>
              <td> <?= $c['email'] ?> </td>
              <?php if($_SESSION['nivel'] > 0) {?>
              <td>
                <form method="POST">
                  <button id="form_borrar" onclick="return confirmacion('Desea realmente borrar este cliente?');" type="submit" name="borrar_id" value="<?= $c['id_cliente']?>" class="btn btn-danger">Borrar</button>
                </form> 
              </td>
              <?php } ?>
            </tr>
        <?php }
          if($this->prefProv != 0 && $this->prefTipo != 0 && ($this->prefTipo == $c["id_tipo_cliente"]) && ($this->prefProv == $c["id_provincia"])){?>
            <tr class="texto">  
              <td><form method="GET"><button type="submit" class="btn btn-primary btn-block" name="client" value="<?= $c['cuit'] ?>"><span class="glyphicon glyphicon-user icono"></span> <?= $c['nombre'] ?> <?= $c['apellido'] ?> </button></form></td>
              <td> <?= $c['provincia'] ?>, <?= $c['localidad'] ?> </td>
              <td> <?= $c['tipo_cliente'] ?> </td> 
              <td> <?= $c['telefono'] ?> </td> 
              <td> <?= $c['cuit'] ?> </td>
              <td> <?= $c['email'] ?> </td>
              <?php if($_SESSION['nivel'] > 0) {?>
              <td>
                <form method="POST">
                  <button id="form_borrar" onclick="return confirmacion('Desea realmente borrar este cliente?');" type="submit" name="borrar_id" value="<?= $c['id_cliente']?>" class="btn btn-danger">Borrar</button>
                </form> 
              </td>
              <?php } ?>
            </tr>
        <?php }
        }
      } ?>
    </tbody>
  </table>
</div>

<form method="POST" action="" id="clientSubmit">
  <input id="client" type="hidden" name="client" value="0" />
</form>

<script src="html/js/general.js"></script>
<script>
  function busqueda(id){
    inputCuit = document.getElementById(id);
    cuit = inputCuit.value;

    if(!cuit_validation(cuit))
    {
      alert("El cuit no es valido, ingreselo nuevamente");
      return false;
    }

    clients = <?php echo json_encode($this->client); ?>;

    for(var i = 0; i < clients.length; i++)
    {
      if((clients[i]["cuit"] == cuit) && clients[i]["activo"])
        return true;
    }

    alert("El cuit no se encuentra en la lista de clientes");

    return false;
  }

  function restaurar_cliente(id){
    inputCuit = document.getElementById(id);
    cuit = inputCuit.value;

    if(!cuit_validation(cuit))
    {
      alert("El cuit no es valido, ingreselo nuevamente");
      return false;
    }

    clients = <?php echo json_encode($this->client); ?>;

    for(var i = 0; i < clients.length; i++)
    {
      if((clients[i]["cuit"] == cuit))
      {
        if(clients[i]["activo"] == true)
        {
          alert("El cliente ya se encuentra activo");

          return false;
        }
        else
          return true;
      }
    }

    alert("El cuit no se encuentra en la lista de clientes");

    return false;
  }

  function cuit_validation(cuit)
  {
    inputString = cuit.toString()
    if (inputString.length == 11) {
        var Caracters_1_2 = inputString.charAt(0) + inputString.charAt(1)
        if (Caracters_1_2 == "20" || Caracters_1_2 == "23" || Caracters_1_2 == "24" || Caracters_1_2 == "27" || Caracters_1_2 == "30" || Caracters_1_2 == "33" || Caracters_1_2 == "34") {
            var Count = inputString.charAt(0) * 5 + inputString.charAt(1) * 4 + inputString.charAt(2) * 3 + 
                        inputString.charAt(3) * 2 + inputString.charAt(4) * 7 + inputString.charAt(5) * 6 + 
                        inputString.charAt(6) * 5 + inputString.charAt(7) * 4 + inputString.charAt(8) * 3 + 
                        inputString.charAt(9) * 2 + inputString.charAt(10) * 1;
            Division = Count / 11;
            if (Division == Math.floor(Division)) {
                return true
            }
        }
    }
    return false
  } 
</script>
</body>
</html>