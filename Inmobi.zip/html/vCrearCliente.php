<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    
    <style>
    
    
 

/* Style inputs, select elements and textareas */
input[type=text], select, textarea{
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  resize: vertical;
}

/* Style the label to display next to the inputs */
label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}
.form{
  display: inline-block;
}
/* Style the submit button */
input[type=submit] {
  background-color: #4CAF50;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

/* Style the container */
.container {
  border-radius: 5px;
  background-color: #f2f2f2;
  padding: 20px;
}

/* Floating column for labels: 25% width */
.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

/* Floating column for inputs: 75% width */
.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Responsive layout - when the screen is less than 600px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .col-25, .col-75, input[type=submit] {
    width: 100%;
    margin-top: 0;
  }
}

</style>
    
    </style>
    <title>Crear Cliente </title>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">INMOBI</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="http://localhost/inmobi/propiedades">Propiedades</a></li>
      <li class="active"><a href="http://localhost/inmobi/clientes">Clientes</a></li>
      <?php if($_SESSION['nivel'] > 0) {?>
        <li><a href="http://localhost/inmobi/usuarios">Usuarios</a></li>
        <li><a href="http://localhost/inmobi/registros">Registros</a></li>
      <?php }?>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><form method="POST"><button type="submit" name="cerrarSesion" class="btn btn-danger boton"><span class="glyphicon glyphicon-user"></span> Cerrar sesion</button></form></li>
      
    </ul>
  </div>
</nav>
  <div class="container">
  <h1 style="text-align: center;"> DATOS DEL CLIENTE </h1>
  <form method="POST" id="form_creacion">
    <div class="row" >
        <div class="col-25">
          <label for="country">Tipo de cliente</label>
        </div>
        <div class="col-75">
          <select onchange="renderPrefs()" id="tipo_cliente" name="tipo_cliente">
            <option value="0">Elige un tipo de cliente...</option> 
            <option value="1">Vendedor</option>  
            <option value="2">Comprador</option>
            <option value="3">Ambos</option>
          </select>
        </div>
      </div>

      <div class="row">
        <div class="col-25">
          <label for="fname">Nombre </label>
        </div>
        <div class="col-75">
          <input type="text" id="nombre" name="nombre" placeholder="Nombre..." minlength="4" maxlength="50">
        </div>
      </div>

      <div class="row">
        <div class="col-25">
          <label for="fname">Apellido </label>
        </div>
        <div class="col-75">
          <input type="text" id="apellido" name="apellido" placeholder="Apellido..." minlength="4" maxlength="50">
        </div>
      </div>

      <div class="row">
        <div class="col-25">
          <label for="fname">Cuit</label>
        </div>
        <div class="col-75">
          <input type="text" id="cuit" name="cuit" placeholder="Ingrese cuit sin (-)" maxlength="11">
        </div>
      </div>
      <div class="row">
        <div class="col-25">
          <label for="fname">Telefono celular o de domicilio </label>
        </div>
        <div class="col-75">
          <input type="text" id="telefono" name="telefono" placeholder="Telefono..." minlength="8" maxlength="10">
        </div>
      </div>
      <div class="row">
        <div class="col-25">
          <label for="fname">Email </label>
        </div>
        <div class="col-75">
          <input type="text" id="email" name="email" placeholder="Email..." maxlength="100">
        </div>
        </div>
        <div class="row">
        <div class="col-25">
          <label for="country">Provincia</label>
        </div>
        <div class="col-75">
          <select onchange="changeLocation('prov', 'loc')" id="prov" name="provincia">
          <option name="tipo" value="0"> Elija una provincia... </option>
          <?php foreach($this->prov as $p) {?>
              <option name="tipo" value="<?= $p['id_provincia']?>"> <?= $p['provincia']?> </option>
            <?php }?>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col-25">
          <label for="country">Localidad</label>
        </div>
        <div class="col-75">
          <select id="loc" name="localidad">
          </select>
        </div>
      </div>

      <div class="row">
        <div class="col-25">
          <label for="fname">Calle </label>
        </div>
        <div class="col-75">
          <input type="text" id="calle" name="calle" placeholder="Calle..." minlength="4" maxlength="200">
        </div>
      </div>

      <div class="row">
        <div class="col-25">
          <label for="fname">Numero </label>
        </div>
        <div class="col-75">
          <input type="number" id="numero" name="numero">
        </div>
      </div>
      
      <script id="preferencias" type="text/html">
      <h1 style="text-align: center;"> PREFERENCIAS DE COMPRA </h1>
      <div class="row">
        <div class="col-25">
          <label for="country">Provincia Preferencia</label>
        </div>
        <div class="col-75">
          <select onchange="changeLocation('pref_prov', 'pref_loc')" id="pref_prov" name="pref_provincia">
          <option name="tipo" value="0"> Elija una provincia... </option>
          <?php foreach($this->prov as $p) {?>
              <option name="tipo" value="<?= $p['id_provincia']?>"> <?= $p['provincia']?> </option>
            <?php }?>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col-25">
          <label for="country">Localidad Preferencia</label>
        </div>
        <div class="col-75">
          <select id="pref_loc" name="pref_localidad">
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col-25">
          <label for="fname">Precio</label>
        </div>
        <div class="col-75">
          <input type="number" id="pref_precio" name="pref_precio" placeholder="Ingrese el precio">
        </div>
      </div>
      <div class="row">
        <div class="col-25">
          <label for="country">Estado</label>
        </div>
        <div class="col-75">
          <select id="pref_estado" name="pref_estado">
          <?php foreach($this->cond as $c) {?>
              <option name="tipo" value="<?= $c['id_estado']?>"> <?= $c['estado']?> </option>
            <?php }?>
          </select>
        </div>
      </div>
      <div class="row">
        <div class="col-25">
          <label for="country">Tipo de casa</label>
        </div>
        <div class="col-75">
          <select id="pref_tipo" name="pref_tipo">
            <?php foreach($this->type as $t) {?>
              <option name="tipo" value="<?= $t['id_tipo']?>"> <?= $t['tipo']?> </option>
            <?php }?>
          </select>
        </div>
      </div>
      </script>

      <div id="botones">
        <button type="submit" name="nuevo_cliente" onclick="return validacion()" class="btn btn-success">Crear</button>
        <form class="form" method="POST" name="cancelar"><button class="btn btn-success">Cancelar</button></form>
      </div>
  </form>
</div>
<script src="html/js/general.js"></script>
<script>
  function renderPrefs()
  {
    if((document.getElementById("tipo_cliente").value > 1) && !document.getElementById("prefs"))
    {
      var div = document.createElement("div");
      div.setAttribute("id", "prefs");
      div.innerHTML = document.getElementById("preferencias").innerHTML;
      var boton = document.getElementById("botones");
      document.getElementById("botones").parentNode.removeChild(document.getElementById("botones"));
      document.getElementById("form_creacion").appendChild(div);
      document.getElementById("form_creacion").appendChild(boton);
    } 
    else
    {
      if(document.getElementById("tipo_cliente").value < 2 && document.getElementById("prefs"))
        document.getElementById("prefs").parentNode.removeChild(document.getElementById("prefs"));
    }
  }

  function changeLocation(prov_id, loc_id)
  {
    array_loc = <?php echo json_encode($this->loc); ?>;
    var prov = document.getElementById(prov_id);
    var loc = document.getElementById(loc_id);
    var valid = [];
    var opcion = prov.options[prov.options.selectedIndex].value;

    while(loc.firstChild){
      loc.removeChild(loc.lastChild);
    }

    for(var i = 0; i < array_loc.length; i++)
    {
      if(array_loc[i]["provincia"] == opcion)
        valid.push(array_loc[i]) 
    }

    for(var i = 0; i < valid.length; i++)
    {
      newLoc = document.createElement("option");
      newLoc.value = valid[i]["id_localidad"];
      newLoc.text = valid[i]["localidad"];
      loc.appendChild(newLoc);
    }
  }

  function validacion()
  {
    clientes = <?php echo json_encode($this->client); ?>;

    if(document.getElementById("tipo_cliente").value == 0)
    {
      alert("Seleccione un tipo de usuario");
      return false;
    }

    if(document.getElementById("nombre").value == "" )
    {
      alert("Todo cliente debe tener un nombre");
      return false;
    }

    if(!/^[a-zA-Z\s]+$/i.test(document.getElementById("nombre").value))
    {
      alert("El nombre no puede contener numeros");
      return false;
    }

    if(document.getElementById("apellido").value == "" )
    {
      alert("Todo cliente debe tener un apellido");
      return false;
    }

    if(!/^[a-zA-Z\s]+$/i.test(document.getElementById("apellido").value))
    {
      alert("El apellido no puede contener numeros");
      return false;
    }

    if(document.getElementById("cuit").value == "")
    {
      alert("Todo cliente debe tener un CUIT");
      return false;
    }

    if(!cuit_validation(document.getElementById("cuit").value))
    {
      alert("El CUIT es erroneo, ingreselo nuevamente");
      return false;
    }

    for(var i = 0; i < clientes.length; i++)
    {
      if(clientes[i]["cuit"] == document.getElementById("cuit").value)
      {
        alert("El cuit ya se encuentra registrado");
        return false;
      }
    }

    if(document.getElementById("telefono").value == "")
    {
      alert("Todo cliente debe tener un telefono");
      return false;
    }

    if(!/^\d+$/.test(document.getElementById("telefono").value))
    {
      alert("El telefono no debe contener letras ni caracteres especiales");
      return false;
    }

    if(document.getElementById("email").value == "")
    {
      alert("Todo cliente debe tener un email");
      return false;
    }

    if(!/^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i.test(document.getElementById("email").value))
    {
      alert("Email erroneo, ingreselo nuevamente");
      return false;
    }

    for(var i = 0; i < clientes.length; i++)
    {
      if(clientes[i]["email"] == document.getElementById("email").value)
      {
        alert("El email ya se encuentra registrado");
        return false;
      }
    }

    if(document.getElementById("prov").value == 0)
    {
      alert("Debe seleccionar una provincia");
      return false;
    }

    if(document.getElementById("calle").value == 0)
    {
      alert("El campo calle no puede estar vacio");
      return false;
    }

    if(!/^[a-zA-Z\s]+$/i.test(document.getElementById("calle").value))
    {
      alert("La calle no puede contener numeros ni caracteres especiales");
      return false;
    }

    if(document.getElementById("numero").value == 0)
    {
      alert("El campo numero no puede estar vacio");
      return false;
    }

    if(!/^\d+$/.test(document.getElementById("numero").value))
    {
      alert("El numero no puede contener letras ni caracteres especiales");
      return false;
    }

    if(document.getElementById("tipo_cliente").value > 1)
    {
      if(document.getElementById("pref_prov").value == 0)
      {
        alert("Debe seleccionar una provincia de preferencia");
        return false;
      }

      if(document.getElementById("pref_precio").value == "")
      {
        alert("El precio de preferencia no puede estar vacio");
        return false;
      }
    }
    
    return true;
  }

  function cuit_validation(cuit)
  {
    inputString = cuit.toString()
    if (inputString.length == 11) {
        var Caracters_1_2 = inputString.charAt(0) + inputString.charAt(1)
        if (Caracters_1_2 == "20" || Caracters_1_2 == "23" || Caracters_1_2 == "24" || Caracters_1_2 == "27" || Caracters_1_2 == "30" || Caracters_1_2 == "33" || Caracters_1_2 == "34") {
            var Count = inputString.charAt(0) * 5 + inputString.charAt(1) * 4 + inputString.charAt(2) * 3 + 
                        inputString.charAt(3) * 2 + inputString.charAt(4) * 7 + inputString.charAt(5) * 6 + 
                        inputString.charAt(6) * 5 + inputString.charAt(7) * 4 + inputString.charAt(8) * 3 + 
                        inputString.charAt(9) * 2 + inputString.charAt(10) * 1;
            Division = Count / 11;
            if (Division == Math.floor(Division)) {
                return true
            }
        }
    }
    return false
  }
</script>
</body>
</html>