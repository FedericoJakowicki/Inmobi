<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    
    <style>
    
    
  input[type=text] {
    width: 75%;
    text-align: center;
    
}
.container input {
  display: block;
  width: 75%;
  clear: both;
  margin-top: 50px;
  margin-left: auto;
  margin-right: auto;
}

.pepe{
  display: block;
  margin-right: 20%;
  margin-left: 20%;
}

.texto{
  text-align: center;
  margin-top: auto;
  }

</style>
    
    </style>
    <title>Operaciones </title>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand">INMOBI</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="http://localhost/Inmobi/propiedades">Propiedades </a></li>
      <li><a href="http://localhost/Inmobi/clientes">Clientes </a></li>
      <?php if($_SESSION['nivel'] > 0) {?>
        <li><a href="http://localhost/inmobi/usuarios">Usuarios</a></li>
        <li class="active"><a href="http://localhost/inmobi/registros">Registros</a></li>
      <?php }?>
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><form method="POST"><button type="submit" name="cerrarSesion" class="btn btn-danger boton"><span class="glyphicon glyphicon-user"></span> Cerrar sesion</button></form></li>

    </ul>
  </div>
</nav>
<div class="fondo-barra">

<div class="container">
  
  <table class="table table-condensed ">
    <thead>
   
      <tr>
        <th class="texto">Usuario</th>
        <th class="texto">Fecha y Hora</th>
        <th class="texto">Tipo de Operacion</th>
      </tr>
      
    </thead>
    <tbody class="texto">
    
      
    <?php foreach($this->task as $t)  {?> 
        <tr>  
    <td><form method="POST"> <button type="submit" name="user" class="btn btn-primary btn-block"
        <?php foreach($this->user as $u){ if($u['id_usuario'] == $t['usuario']){?> 
          value=<?= $u['id_usuario'] ?> <?php $this->userTask = $u['nombre_usuario']; } } ?>>
          <span class="glyphicon glyphicon-user icono"></span> <?= $this->userTask ?>   
          </button></form></td>
          <td> <?= $t['fecha'] ?> </td>
          <td> <?= $t['descripcion'] ?> </td> 
        </tr>
      <?php } ?>
      
      
    </tbody>
  </table>
  
</div>
</body>
</html>