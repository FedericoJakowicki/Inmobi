<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <title>Document</title>
</head>
<body>
<div class="container ">
  
<img src="controllers/img/<?= $this->user['nombre_usuario']  ?>.jpg" class=" center" alt="Cara de empleado" >
<form class="form-horizontal" method="Post">
<div class="form-group center">
    <label class="control-label col-sm-10  " for="pwd">Password:</label>
    <div class="col-sm-10 center">
      <input type="password" class="form-control center" id="contraseña" name="contraseña" placeholder="Ingrese su contraseña">
    </div>
  </div>
  
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10 center">
      <div class="checkbox mx-auto d-block">
        <label><input type="checkbox" > Recordarme</label>
      </div>
    </div>
  </div>
  <div class="form-group">
    <div class="col-sm-offset-2 col-sm-10 center">
      <input type="hidden" name="user" value="<?= $_POST['user'] ?>">
      <button type="submit"  class="btn btn-success center ">Ingresar</button>
      
    </div>
  </div>
</form>
</div>
</body>
</html>
<style>
.center{
  display: block;
  margin-left: auto;
  margin-right: auto;
  text-align: center;
  
}
body {
  background-image: url("controllers/img/insta.jpg");

  

  /* Full height */
  height: 100%;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
}
img{
   
    display: block;
    margin-right: auto;
    margin-left: auto;
    
    border-radius: 200px;
    border: 10px solid #ffffff;
    height: 250px;
    width: 250px;
    margin-top: 50px;
    
    margin-bottom:50px ;
}

</style>
