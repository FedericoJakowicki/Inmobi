<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
      
    <style>
    body {
        background-color: gray    ;
          
    }
    img{
      display: block;
      margin-right: auto;
      margin-left: auto;
      height: 250px;
      width: 250px;
      margin-top: 15px;
      margin-bottom:50px ;
    
    }
    .form{
      display: inline-block;
    }
    .boton{
    margin-top: 6%;
    position: relative;
    right: 10px;
    }

    .biografia{
    text-align:Center ;
    font-family: Arial;
    font-weight: 700;
    }

    .pepe {
    padding: 80px 120px;
    }
    </style>

    <title>Editar un cliente</title>
  </head>

  <body>
    <nav class="navbar navbar-inverse">
      <div class="container-fluid">
        <div class="navbar-header">
          <a class="navbar-brand">INMOBI</a>
        </div>
        <ul class="nav navbar-nav">
          <li><a href="http://localhost/Inmobi/propiedades">Propiedades</a></li>
          <li class="active"><a href="http://localhost/Inmobi/clientes">Clientes</a></li>
          <li><a href="http://localhost/inmobi/usuarios">Usuarios</a></li>
          <li><a href="http://localhost/inmobi/registros">Registros</a></li>
        
        </ul>
        <ul class="nav navbar-nav navbar-right">
          <li><form method="POST"><button type="submit" name="cerrarSesion" class="btn btn-danger boton"><span class="glyphicon glyphicon-user"></span> Cerrar sesion</button></form></li>
        </ul>
      </div>
    </nav>

    <div class="container">
      <div class="row">
      <form method="POST">
        <div class="col-sm-4">
          <h3>  
              <label for="fname">Nombre </label>
              <input type="text" id="fname" name="nombre" value=<?= $this->client['nombre']?> maxlength="50">
              <label for="fname">Apellido </label>
              <input type="text" id="fname" name="apellido" value=<?= $this->client['apellido']?> maxlength="50">
          </h3>
          <img src="html/img/usuario.png"  alt="Cara logo">
        </div>
          
        <div class="col-sm-4" id="info">
          <h1> INFORMACION </h1>
          <div>
            <label for="fname">Calle</label>
            <input type="text" id="fname" name="calle" value="<?= $this->client['calle']?>" maxlength="50">
          </div>
          <div>
            <label for="fname">Numero</label>
            <input type="text" id="fname" name="numero" value="<?= $this->client['numero']?>" maxlength="50">
          </div>
          <div>
            <label for="country">Tipo de cliente</label>
            <select onchange="renderPrefs()" id="nivel" name="tipo_cliente">
              <option value="1">Vendedor</option>  
              <option value="2">Comprador</option>
              <option value="3">Ambos</option>
            </select>
          </div>

          <div>
            <label for="fname">Cuit </label>
            <input type="text" id="fname" name="cuit" value="<?= $this->client['cuit'] ?> " maxlength="50">
          </div>
          <div>
            <label for="fname">Telefono</label>
            <input type="text" id="fname" name="telefono" value=" <?= $this->client['telefono'] ?>" maxlength="50">
          </div>
          <div>
            <label for="fname">Email</label>
            <input type="text" id="fname" name="email" value=" <?= $this->client['email'] ?>" maxlength="50">
          </div>
          <div>
            <label for="fname">Provincia</label>
            <select onchange="changeLocation('prov', 'loc')" id="prov" name="prov">
              <option value="0"></option> 
              <?php foreach($this->prov as $p) {?>
                <option value="<?= $p['id_provincia'] ?>"> <?= $p['provincia'] ?> </option>  
              <?php }?>
            </select>
          </div>
          <div>
            <label for="fname">Localidad</label>
            <select id="loc" name="loc">
            </select>
          </div>

          <script id="preferencias" type="text/html">
            <h2>PREFERENCIAS</h2>
            <div>
              <label for="fname">Provincia</label>
              <select onchange="changeLocation('pref_prov', 'pref_loc')" id="pref_prov" name="pref_prov">
                <option value="0"></option> 
                <?php foreach($this->prov as $p) {?>
                  <option value="<?= $p['id_provincia'] ?>"> <?= $p['provincia'] ?> </option>  
                <?php }?>
              </select>
            </div>
            <div>
              <label for="fname">Localidad</label>
              <select id="pref_loc" name="pref_loc">
              </select>
            </div>
            <div>
              <label for="fname">Estado </label>
              <select name="pref_estado">
                <?php foreach($this->estado as $e) {?>
                  <option value="<?= $e['id_estado'] ?>"> <?= $e['estado'] ?> </option>  
                <?php }?>
              </select>
            </div>
            <div>
              <label for="fname">Tipo</label>
              <select name="pref_tipo">
                <?php foreach($this->tipo as $t) {?>
                  <option value="<?= $t['id_tipo'] ?>"> <?= $t['tipo'] ?> </option>  
                <?php }?>
              </select>
            </div>
            <div>
              <label for="fname">Precio</label>
              <input type="text" id="fname" name="pref_precio" placeholder="Precio de preferencia..." maxlength="50">
            </div>
          </script>
          <div id="botones">
            <button type="submit" class="btn btn-success" name="editar">Aceptar</button>
            <form class="form" method="POST"><button type="submit" name="cancelar" class="btn btn-success">Cancelar</button></form>
          </div>
          <input type="hidden" name="cuit_client" value="<?= $_GET['client'] ?>">
        </div>
        
      </form> 
      <img src="html/img/inmobi.jpg" class="img-thumbnail" alt="logo inmobi">
      
      </div>
    </div>

    <script>
      function renderPrefs()
      {
        if((document.getElementById("nivel").value == 2 || document.getElementById("nivel").value == 3) && !document.getElementById("prefs"))
        {
          var div = document.createElement("div");
          div.setAttribute("id", "prefs");
          div.innerHTML = document.getElementById("preferencias").innerHTML;
          var boton = document.getElementById("botones");
          document.getElementById("botones").parentNode.removeChild(document.getElementById("botones"));
          document.getElementById("info").appendChild(div);
          document.getElementById("info").appendChild(boton);
        } 
        else
        {
          if(document.getElementById("nivel").value == 1)
            document.getElementById("prefs").parentNode.removeChild(document.getElementById("prefs"));
        }
      }

      function changeLocation(prov_id,loc_id){
        var array_loc = <?php echo json_encode($this->loc); ?>;
        var prov = document.getElementById(prov_id);
        var loc = document.getElementById(loc_id);
        var valid = [];
        var opcion = prov.options[prov.options.selectedIndex].value;

        while(loc.firstChild){
          loc.removeChild(loc.lastChild);
        }

        for(var i = 0; i < array_loc.length; i++)
        {
          if(array_loc[i]["provincia"] == opcion)
            valid.push(array_loc[i]) 
        }

        for(var i = 0; i < valid.length; i++)
        {
          newLoc = document.createElement("option");
          newLoc.value = valid[i]["id_localidad"];
          newLoc.text = valid[i]["localidad"];
          loc.appendChild(newLoc);
        }      
      }
    </script>

    <script src="html/js/general.js"></script>
  </body>
</html>

