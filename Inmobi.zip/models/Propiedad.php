<?php
    //models/..Propiedad.php

    require '../models/Detalle.php';
    
    class Propiedad extends Model{

        public function getTodos()
        {
            $this->db->query("SELECT * FROM propiedad
                                LEFT JOIN ubicacion ON
                                    propiedad.ubicacion = ubicacion.id_ubicacion
                                    LEFT JOIN direccion ON
                                    ubicacion.direccion = direccion.id_direccion
                                    LEFT JOIN localidad ON
                                    direccion.localidad = localidad.id_localidad
                                    LEFT JOIN provincia ON
                                    localidad.provincia = provincia.id_provincia
                                LEFT JOIN detalle ON
                                    detalle.id_detalle = propiedad.detalle
                                    LEFT JOIN caracteristicas ON
                                    detalle.caracteristicas = caracteristicas.id_caracteristicas
                                    LEFT JOIN tipo ON
                                    detalle.tipo = tipo.id_tipo
                                    LEFT JOIN estado ON
                                    detalle.estado = estado.id_estado
                                LEFT JOIN operacion ON
                                    propiedad.operacion = operacion.id_operacion");
            return $this->db->fetchAll();
        }

        public function getPropiedad($id)
        { 
            if(!ctype_digit($id)) throw new ValidacionException('Error: tipo no numero');
            if($id < 1) throw new ValidacionException('Error: numero negativo ');

            $this->db->query("SELECT * 
                                FROM propiedad
                                    LEFT JOIN ubicacion ON
                                        propiedad.ubicacion = ubicacion.id_ubicacion
                                        LEFT JOIN direccion ON
                                        ubicacion.direccion = direccion.id_direccion
                                        LEFT JOIN localidad ON
                                        direccion.localidad = localidad.id_localidad
                                        LEFT JOIN provincia ON
                                        localidad.provincia = provincia.id_provincia
                                    LEFT JOIN detalle ON
                                        detalle.id_detalle = propiedad.detalle
                                        LEFT JOIN caracteristicas ON
                                        detalle.caracteristicas = caracteristicas.id_caracteristicas
                                        LEFT JOIN tipo ON
                                        detalle.tipo = tipo.id_tipo
                                        LEFT JOIN estado ON
                                        detalle.estado = estado.id_estado
                                    LEFT JOIN vendedor ON
                                        propiedad.dueño = vendedor.id_vendedor
                                    LEFT JOIN operacion ON
                                        propiedad.operacion = operacion.id_operacion
                                    WHERE propiedad.id_propiedad = '$id'
                                        LIMIT 1");

            return $this->db->fetch();
        }

        public function newPropiedad($ubicacion, $dueño, $reservado, $detalle, $operacion)
        {
            if(!is_array($detalle)) throw new ValidacionException('Error: tipo no array');
            if(!is_array($ubicacion)) throw new ValidacionException('Error: tipo no array');
            if(!is_bool($reservado)) throw new ValidacionException('Error: tipo no numero');

            $dueño = $this->db->escape($dueño);
            if(!ctype_digit($dueño)) throw new ValidacionException('Error: tipo no numero');
            if($dueño < 1) throw new ValidacionException('Error: numero negativo ');

            $operacion  = $this->db->escape($operacion);
            if(!ctype_digit($operacion)) throw new ValidacionException('Error: tipo no numero');
            if($operacion < 1) throw new ValidacionException('Error: numero negativo ');
            
            $ubi = new Ubicacion();
            if(!$ubi = $ubi->newUbicacion($ubicacion['calle'], $ubicacion['numero'], $ubicacion['localidad']))
            {
                throw new ValidacionException('Error: creacion de ubicacion');
            }

            $newDetalle = new Detalle();
            if($newDetalle = $newDetalle->newDetalle($detalle))
            {
                $this->db->query("INSERT INTO propiedad (reservado, detalle, dueño, operacion, ubicacion, activo)
                                        VALUES ('$reservado','$newDetalle', $dueño, $operacion, $ubi,1)");
            }
            else
            {
                throw new ValidacionException('Error: creacion de detalle');
            }

            return $this->db->insert_id();
        }

        public function set_prop_inactivo($id)
        {
            $id = $this->db->escape($id);
            if(!ctype_digit($id)) throw new ValidacionException('Error: tipo no numero');
            $this->db->query("UPDATE propiedad 
                                        SET activo = 0
                                        WHERE id_propiedad = '$id'");
        }

        public function restaurar_dueño($id)
        {
            $id = $this->db->escape($id);
            if(!ctype_digit($id)) throw new ValidacionException('Error: tipo no numero');

            $this->db->query("UPDATE propiedad 
                                        SET activo = 1
                                        WHERE dueño = '$id'");
        }
    }
?>