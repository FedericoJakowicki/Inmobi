<?php
    //models/..

    class Estado extends Model{

        public function getEstados()
        {
            $this->db->query("SELECT * FROM estado");
            return $this->db->fetchAll();
        }
    }
?>