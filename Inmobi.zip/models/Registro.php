<?php
    //models/..
   
    
    class Registro extends Model{

        public function getTodos()
        {
            $this->db->query("SELECT * FROM registro ORDER BY fecha DESC");
            return $this->db->fetchAll();
        }

        public function getRegistro($id)
        {
            $id = $this->db->escape($id);
            if(!ctype_digit($id)) throw new ValidacionException('Error: tipo no numero');
            if($id < 1) throw new ValidacionException('Error: numero negativo ');

            $this->db->query("SELECT * FROM registro
                                    WHERE id_registro = '$id'
                                        LIMIT 1");

            return $this->db->fetch();
        }

        public function newRegistro($descripcion, $usuario)
        {
            $descripcion = $this->db->escape($descripcion);
            if(strlen($descripcion) < 1 )throw new ValidacionException('Error: no hay descipcion');
            if(strlen($descripcion) > 500 )throw new ValidacionException('Error: no hay descipcion');

            if(!ctype_digit($usuario)) throw new ValidacionException('Error: tipo no numero');
            if($usuario < 1) throw new ValidacionException('Error: numero negativo ');

            $this->db->query("INSERT INTO registro (descripcion, usuario)
                             VALUE ('$descripcion','$usuario')");

            return $this->db->insert_id();
        }
    }
?>