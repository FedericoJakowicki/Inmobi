<?php
    //models/..
    require '../models/Caracteristica.php';

    class Detalle extends Model{
        public function getDetalle($id)
        {
            $id = $this->db->escape($id);
            if(!ctype_digit($id)) throw new ValidacionException('Error: tipo no numero');
            
            $this->db->query("SELECT * 
                                FROM detalle
                                    WHERE id_detalle = '$id'
                                        LEFT JOIN detalle.ubicacion = ubicacion.id_ubicacion
                                            LIMIT 1");
                                            
            return $this->db->fetch();
        }

        public function newDetalle($detalle)
        {
            //VALIDACIONES
            if(!is_array($detalle)) throw new ValidacionException('Error: tipo no array');
            if(!is_array($detalle['caracteristicas'])) throw new ValidacionException('Error: tipo no array');

            $newCaract = new Caracteristica();
            $newCaract = $newCaract->newCaract($detalle['caracteristicas']); 

            $descripcion = $this->db->escape($detalle['descripcion']);
            if(!is_numeric($detalle['precio'])) throw new ValidacionException('Error: tipo no numero');
            $precio = $this->db->escape($detalle['precio']);
            $muebles = $this->db->escape($detalle['muebles']);
            if(!ctype_digit($detalle['estado'])) throw new ValidacionException('Error: tipo no numero');
            $estado = $this->db->escape($detalle['estado']);
            if(!ctype_digit($detalle['baños'])) throw new ValidacionException('Error: tipo no numero');
            $baños = $this->db->escape($detalle['baños']);
            if(!ctype_digit($detalle['habitaciones'])) throw new ValidacionException('Error: tipo no numero');
            $habitaciones = $this->db->escape($detalle['habitaciones']);
            if(!ctype_digit($detalle['tipo'])) throw new ValidacionException('Error: tipo no numero');
            $tipo = $this->db->escape($detalle['tipo']);
            if(!ctype_digit($detalle['tamaño'])) throw new ValidacionException('Error: tipo no numero');
            $tamaño = $this->db->escape($detalle['tamaño']);

            $this->db->query("INSERT INTO detalle (descripcion, precio, muebles, estado, 
                            caracteristicas, baños, habitaciones, tipo, tamaño)
                                VALUES ('$descripcion','$precio','$muebles','$estado','$newCaract','$baños',
                                    '$habitaciones','$tipo','$tamaño')");
            
            // RETORNA EL ID DE LA ULTIMA FILA INGRESADA EN DETALLE
            return $this->db->insert_id();
        }
    }
?>