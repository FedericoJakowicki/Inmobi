<?php
    //models/..
   
    
    class Preferencia extends Model{

        public function getTodos()
        {
            $this->db->query("SELECT * FROM preferencia
                                        LEFT JOIN localidad ON
                                        preferencia.localidad = localidad.id_localidad
                                        LEFT JOIN provincia ON
                                        localidad.provincia = provincia.id_provincia
                                        LEFT JOIN estado ON
                                        preferencia.estado = estado.id_estado
                                        LEFT JOIN tipo ON
                                        preferencia.tipo = tipo.id_tipo");
            return $this->db->fetchAll();
        }

        public function getPreferencia($id)
        {
            $id = $this->db->escape($id);
            if(!ctype_digit($id)) throw new ValidacionException('Error: tipo no numero');
            if($id < 1) throw new ValidacionException('Error: numero negativo ');
            
            $this->db->query("SELECT * FROM preferencia
                                    LEFT JOIN localidad ON
                                    preferencia.localidad = localidad.id_localidad
                                    LEFT JOIN provincia ON
                                    localidad.provincia = provincia.id_provincia
                                    LEFT JOIN estado ON
                                    preferencia.estado = estado.id_estado
                                    LEFT JOIN tipo ON
                                    preferencia.tipo = tipo.id_tipo
                                    WHERE id_preferencia = '$id'
                                        LIMIT 1");

            return $this->db->fetch();
        }

        public function newPreferencia($localidad, $precio, $estado, $tipo)
        {
            $localidad = $this->db->escape($localidad);
            if(!ctype_digit($localidad)) throw new ValidacionException('Error: tipo no numero');
            if($localidad < 1) throw new ValidacionException('Error: numero negativo ');

            $precio = $this->db->escape($precio);
            if(!is_numeric($precio)) throw new ValidacionException('Error: tipo no numero');
            if($precio < 1) throw new ValidacionException('Error: numero negativo ');

            $estado = $this->db->escape($estado);
            if(!ctype_digit($estado)) throw new ValidacionException('Error: tipo no numero');
            if($estado < 1) throw new ValidacionException('Error: numero negativo ');

            $tipo = $this->db->escape($tipo);
            if(!ctype_digit($tipo)) throw new ValidacionException('Error: tipo no numero');
            if($tipo < 1) throw new ValidacionException('Error: numero negativo ');

            $this->db->query("INSERT INTO preferencia (localidad, precio, estado, tipo)
                             VALUE ('$localidad','$precio','$estado','$tipo')");

            return $this->db->insert_id();
        }
    }
?>