<?php
    //models/..

    class Tipo extends Model{

        public function getTipos()
        {
            $this->db->query("SELECT * FROM tipo");
            return $this->db->fetchAll();
        }
    }
?>