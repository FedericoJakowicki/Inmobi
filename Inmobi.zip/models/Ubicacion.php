<?php
    //models/..

    class Ubicacion extends Model{

        public function getLocalidades()
        {
            $this->db->query("SELECT * FROM localidad");
            return $this->db->fetchAll();
        }

        public function getProvincias()
        {
            $this->db->query("SELECT * FROM provincia");
            return $this->db->fetchAll();
        }

        public function getUbicacion($id)
        {
            if(!ctype_digit($id)) throw new ValidacionException('Error: tipo no numero');
            if($id < 1) throw new ValidacionException('Error: numero negativo ');

            $this->db->query("SELECT * FROM ubicacion
                                        WHERE calle = '$id'");
            return $this->db->fetch();
        }

        public function newUbicacion($calle, $numero, $localidad)
        {
            $calle = $this->db->escape($calle);
            if(strlen($calle) < 1 ) throw new ValidacionException('Error: calle esta vacio');

            $numero = $this->db->escape($numero);
            if(!ctype_digit($numero)) throw new ValidacionException('Error: tipo no numero');
            if($numero < 1) throw new ValidacionException('Error: numero negativo ');

            $localidad = $this->db->escape($localidad);
            if(!ctype_digit($localidad)) throw new ValidacionException('Error: tipo no numero');
            if($localidad < 1) throw new ValidacionException('Error: numero negativo ');



            $this->db->query("INSERT INTO direccion (calle, numero, localidad)
                            VALUES ('$calle', '$numero', '$localidad')");
            
            $dir = $this->db->insert_id();

            $this->db->query("INSERT INTO ubicacion (direccion)
                            VALUES ('$dir')");
            
            // RETORNA EL ID DE LA ULTIMA FILA INGRESADA EN UBICACION
            return $this->db->insert_id();
        }
    }
?>