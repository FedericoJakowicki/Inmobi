<?php
    //models/..
    
    class Usuario extends Model{
        public function comprobar($usuario, $contraseña)
        {   
            if(strlen($usuario) < 1)throw new ValidacionException('Error: usuario vacio ');
            $usuario = $this->db->escape($usuario);
            
            if(strlen($contraseña) < 5)throw new ValidacionException('Error: contraseña vacia o corta ');
            $contraseña = $this->db->escape($contraseña);

            $this->db->query("SELECT * 
                                FROM usuario 
                                    WHERE (nombre_usuario = '$usuario' OR email = '$usuario') AND contraseña = sha1('$contraseña')
                                        LIMIT 1");

            return $this->db->fetch();
        }

        public function getTodos()
        {
            $this->db->query("SELECT * FROM usuario ORDER BY apellido ASC");
            return $this->db->fetchAll();
        }

        public function getUsuario($usuario)
        {   
            if(strlen($usuario)<1)throw new ValidacionException('Error: usuario vacio ');
            $usuario = $this->db->escape($usuario);

            $this->db->query("SELECT * 
                                FROM usuario
                                    WHERE nombre_usuario = '$usuario' OR email = '$usuario'
                                        LIMIT 1");

            return $this->db->fetch();
        }
        
        public function set_usuario_inactivo($nickname)
        {   
            if(strlen($nickname)<1)throw new ValidacionException('Error: nickname vacio ');
            $nickname = $this->db->escape($nickname);
            $this->db->query("UPDATE usuario
                                        SET activo = 0
                                        WHERE nombre_usuario = '$nickname'");
        }

        public function newUsuario($nickname,$contraseña,$nombre,$apellido,$email,$telefono,$nivel)
        {   
            if(strlen($nickname)<1)throw new ValidacionException('Error: nickname vacio ');
            $nickname = $this->db->escape($nickname);

            if(strlen($contraseña)<1)throw new ValidacionException('Error: contraseña vacio ');
            $contraseña = $this->db->escape($contraseña);

            if(strlen($nombre)<1)throw new ValidacionException('Error: nombre vacio ');
            $nombre = $this->db->escape($nombre);

            if(strlen($apellido)<1)throw new ValidacionException('Error: apellido vacio ');
            $apellido = $this->db->escape($apellido);

            if(strlen($email)<1)throw new ValidacionException('Error: email vacio ');
            $email = $this->db->escape($email);

            if(!ctype_digit($telefono)) throw new ValidacionException('Error: tipo no numero');
            if($telefono < 0) throw new ValidacionException('Error: numero negativo ');

            if(!ctype_digit($nivel)) throw new ValidacionException('Error: tipo no numero');
            if($nivel < 0) throw new ValidacionException('Error: numero negativo ');

            $this->db->query("INSERT INTO usuario (nombre_usuario, contraseña, nombre, 
                                                    apellido, email, telefono, nivel, activo)
                                                VALUE ('$nickname', sha1('$contraseña'), '$nombre','$apellido',
                                                        '$email', $telefono, $nivel, '1')");

            return $this->db->insert_id();
        }
    }
?>