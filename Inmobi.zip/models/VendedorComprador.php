<?php
    //models/..
    
    class Vendedor_Comprador extends Model{

        public function getTodos()
        {
            $this->db->query("SELECT * FROM vendedor_comprador
                                        LEFT JOIN preferencia ON
                                        vendedor_comprador.preferencia = preferencia.id_preferencia
                                        LEFT JOIN localidad ON
                                        preferencia.localidad = localidad.id_localidad
                                        LEFT JOIN provincia ON
                                        localidad.provincia = provincia.id_provincia
                                        LEFT JOIN estado ON
                                        preferencia.estado = estado.id_estado
                                        LEFT JOIN tipo ON
                                        preferencia.tipo = tipo.id_tipo
                                        LEFT JOIN cliente ON
                                        vendedor_comprador.cliente = cliente.id_cliente");
            return $this->db->fetchAll();
        }

        public function getVendedorComprador($cuit)
        {
            $cuit = $this->db->escape($cuit);
            if(!ctype_digit($cuit)) throw new ValidacionException('Error: tipo no numero');
            if($cuit < 1) throw new ValidacionException('Error:  numero menor a 0');

            $this->db->query("SELECT * 
                                FROM vendedor_comprador
                                LEFT JOIN preferencia ON
                                vendedor_comprador.preferencia = preferencia.id_preferencia
                                LEFT JOIN localidad ON
                                preferencia.localidad = localidad.id_localidad
                                LEFT JOIN provincia ON
                                localidad.provincia = provincia.id_provincia
                                LEFT JOIN estado ON
                                preferencia.estado = estado.id_estado
                                LEFT JOIN tipo ON
                                preferencia.tipo = tipo.id_tipo
                                LEFT JOIN cliente ON
                                vendedor_comprador.cliente = cliente.id_cliente
                                    WHERE cuit = '$cuit'
                                        LIMIT 1");

            return $this->db->fetch();
        }

        public function newVendedorComprador($cliente,$preferencia)
        {
            $cliente = $this->db->escape($cliente);
            if(!ctype_digit($cliente)) throw new ValidacionException('Error: tipo no numero');
            if($cliente < 0) throw new ValidacionException('Error: numero negativo ');
            
            $preferencia = $this->db->escape($preferencia);
            if(!ctype_digit($preferencia)) throw new ValidacionException('Error: tipo no numero');
            if($preferencia < 0) throw new ValidacionException('Error: preferencia numero negativo ');

            $this->db->query("INSERT INTO vendedor_comprador (cliente, preferencia)
                             VALUE ('$cliente','$preferencia')");

            return $this->db->insert_id();
        }
    }