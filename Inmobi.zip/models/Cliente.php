<?php
    //models/..
    require '../models/Vendedor.php';
    require '../models/Comprador.php';
    require '../models/VendedorComprador.php';
    require '../models/Preferencia.php';

    class Cliente extends Model{
        
        public function getTodos()
        {
            $this->db->query("SELECT * FROM cliente
                                        LEFT JOIN ubicacion ON
                                        cliente.ubicacion = ubicacion.id_ubicacion
                                        LEFT JOIN direccion ON
                                        ubicacion.direccion = direccion.id_direccion
                                        LEFT JOIN localidad ON
                                        direccion.localidad = localidad.id_localidad
                                        LEFT JOIN provincia ON
                                        localidad.provincia = provincia.id_provincia
                                        LEFT JOIN tipo_cliente ON
                                        cliente.tipo_cliente = tipo_cliente.id_tipo_cliente
                                        ORDER BY apellido ASC");   
            
            return $this->db->fetchAll();
        }

        public function getCliente($cuit)
        {
            if(!ctype_digit($cuit)) throw new ValidacionException('Error: tipo no numero');
            if(strlen($cuit) < 11 ) throw new ValidacionException('Error: nombre vacio');
            if(strlen($cuit) > 11 ) throw new ValidacionException('Error: nombre mas largo del permitido');

            $this->db->query("SELECT * FROM cliente
                                        LEFT JOIN ubicacion ON
                                        cliente.ubicacion = ubicacion.id_ubicacion
                                        LEFT JOIN direccion ON
                                        ubicacion.direccion = direccion.id_direccion
                                        LEFT JOIN localidad ON
                                        direccion.localidad = localidad.id_localidad
                                        LEFT JOIN provincia ON
                                        localidad.provincia = provincia.id_provincia
                                        LEFT JOIN tipo_cliente ON
                                        cliente.tipo_cliente = tipo_cliente.id_tipo_cliente
                                        WHERE cuit = '$cuit'
                                            LIMIT 1");

            return $this->db->fetch();
        }

        public function getClienteById($id)
        {
            $id = $this->db->escape($id);
            if($id < 1) throw new ValidacionException('Error: numero negativo '); 

            $this->db->query("SELECT * FROM cliente
                                        LEFT JOIN ubicacion ON
                                        cliente.ubicacion = ubicacion.id_ubicacion
                                        LEFT JOIN direccion ON
                                        ubicacion.direccion = direccion.id_direccion
                                        LEFT JOIN localidad ON
                                        direccion.localidad = localidad.id_localidad
                                        LEFT JOIN provincia ON
                                        localidad.provincia = provincia.id_provincia
                                        LEFT JOIN tipo_cliente ON
                                        cliente.tipo_cliente = tipo_cliente.id_tipo_cliente
                                        WHERE id_cliente = '$id'
                                            LIMIT 1");

            return $this->db->fetch();
        }

        public function set_client_inactivo($id)
        {
            $id = $this->db->escape($id);
            if($id < 1) throw new ValidacionException('Error: numero negativo '); 

            $this->db->query("UPDATE cliente 
                                        SET activo = 0
                                        WHERE id_cliente = '$id'");
        }

        public function restaurar($cuit)
        {
            $id = $this->db->escape($cuit);
            if(strlen($cuit) < 11 ) throw new ValidacionException('Error: nombre vacio');
            if(strlen($cuit) > 11 ) throw new ValidacionException('Error: nombre mas largo del permitido');

            $this->db->query("UPDATE cliente 
                                        SET activo = 1
                                        WHERE cuit = '$cuit'");
        }

        public function newCliente($tipo, $datos)
        {
            //VALIDACIONES
            if(!is_array($datos)) throw new ValidacionException('Error: tipo no array');
            if(!is_array($datos['ubicacion'])) throw new ValidacionException('Error: tipo no array');
            
            $nombre = $this->db->escape($datos['nombre']);
            if(strlen($nombre) < 1 ) throw new ValidacionException('Error: nombre vacio');
            if(strlen($nombre) > 50 ) throw new ValidacionException('Error: nombre mas largo del permitido');

            $apellido = $this->db->escape($datos['apellido']);
            if(strlen($apellido) < 1 ) throw new ValidacionException('Error: apellido vacio');
            if(strlen($apellido) > 50 ) throw new ValidacionException('Error: apellido mas largo del permitido');

            $cuit = $this->db->escape($datos['cuit']);
            if(!ctype_digit($cuit)) throw new ValidacionException('Error: tipo no numero');
            if($cuit < 1) throw new ValidacionException('Error: numero negativo '); 

            $telefono = $this->db->escape($datos['telefono']);
            if(!ctype_digit($telefono)) throw new ValidacionException('Error: tipo no numero');
            if($telefono < 1) throw new ValidacionException('Error: numero negativo ');

            $email = $this->db->escape($datos['email']);
            if(strlen($email) < 1 ) throw new ValidacionException('Error: email vacio');
            if(strlen($email) > 50 ) throw new ValidacionException('Error: email mas largo del permitido');


            $ubicacion = $datos['ubicacion'];

            $calle = $this->db->escape($ubicacion['calle']);
            if(strlen($calle) < 1 ) throw new ValidacionException('Error: calle vacio');
            if(strlen($calle) > 50 ) throw new ValidacionException('Error: calle mas largo del permitido');

            $numero = $this->db->escape($ubicacion['numero']);
            if(!ctype_digit($numero)) throw new ValidacionException('Error: tipo no numero');
            if($numero < 1) throw new ValidacionException('Error: numero negativo ');

            $localidad = $this->db->escape($ubicacion['localidad']);
            if(!ctype_digit($localidad)) throw new ValidacionException('Error: tipo no numero');
            if($localidad < 1) throw new ValidacionException('Error: numero negativo ');

            $ubi = new Ubicacion();
            $ubi->newUbicacion($calle, $numero, $localidad);
            $ubi = $this->db->insert_id();

            if($tipo == 1)
            {
                $this->db->query("INSERT INTO cliente (nombre, apellido, cuit, telefono, 
                                                        ubicacion, tipo_cliente, email, activo)
                                            VALUE ('$nombre','$apellido','$cuit','$telefono',
                                                    '$ubi','$tipo','$email', 1)");

                $cl = $this->db->insert_id();

                $v = new Vendedor();
                $v->newVendedor($cl);

                return $cl;
            }
            else
            {
                if($tipo == 2)
                {
                    $this->db->query("INSERT INTO cliente (nombre, apellido, cuit, telefono, 
                                                            ubicacion, tipo_cliente, email, activo)
                                                VALUE ('$nombre','$apellido','$cuit','$telefono',
                                                        '$ubi','$tipo','$email', 1)");
                                                        
                    $cl = $this->db->insert_id();
                    $pref = new Preferencia();
                    $localidad = $datos['pref_localidad'];
                    if(!ctype_digit($localidad)) throw new ValidacionException('Error: tipo no numero');
                    if($localidad < 1) throw new ValidacionException('Error: numero negativo ');

                    $precio = $datos['pref_precio'];
                    if(!ctype_digit($precio)) throw new ValidacionException('Error: tipo no numero');
                    if($precio < 1) throw new ValidacionException('Error: numero negativo ');

                    $estado = $datos['pref_estado'];
                    if(!ctype_digit($estado)) throw new ValidacionException('Error: tipo no numero');
                    if($estado < 1) throw new ValidacionException('Error: numero negativo ');

                    $tipo = $datos['pref_tipo'];
                    if(!ctype_digit($tipo)) throw new ValidacionException('Error: tipo no numero');
                    if($tipo < 1) throw new ValidacionException('Error: numero negativo ');

                    $pref = $pref->newPreferencia($localidad, $precio, $estado, $tipo);

                    $c = new Comprador();
                    $c->newComprador($cl, $pref);                    

                    return $cl;
                }
                else
                {
                    $this->db->query("INSERT INTO cliente (nombre, apellido, cuit, telefono, 
                                                            ubicacion, tipo_cliente, email, activo)
                                                VALUE ('$nombre','$apellido','$cuit','$telefono',
                                                        '$ubi','$tipo','$email', 1)");
                                                        
                    $cl = $this->db->insert_id();
                    $pref = new Preferencia();
                    $localidad = $datos['pref_localidad'];
                    if(!ctype_digit($localidad)) throw new ValidacionException('Error: tipo no numero');
                    if($localidad < 1) throw new ValidacionException('Error: numero negativo ');

                    $precio = $datos['pref_precio'];
                    if(!is_numeric($precio)) throw new ValidacionException('Error: tipo no numero');
                    if($precio < 1) throw new ValidacionException('Error: numero negativo ');

                    $estado = $datos['pref_estado'];
                    if(!ctype_digit($estado)) throw new ValidacionException('Error: tipo no numero');
                    if($estado < 1) throw new ValidacionException('Error: numero negativo ');

                    $tipo = $datos['pref_tipo'];
                    if(!ctype_digit($tipo)) throw new ValidacionException('Error: tipo no numero');
                    if($tipo < 1) throw new ValidacionException('Error: numero negativo ');

                    $pref->newPreferencia($localidad, $precio, $estado, $tipo);
                    $pref = $this->db->insert_id();

                    $cv = new Vendedor_Comprador();
                    $cv->newVendedorComprador($cl, $pref);

                    return $cl;
                }
            }
        }
    }
?>