<?php
    //models/..
    
    
    class Vendedor extends Model{

        public function getTodos()
        {
            $this->db->query("SELECT * FROM vendedor
                                        LEFT JOIN cliente ON
                                        vendedor.cliente = cliente.id_cliente");
            return $this->db->fetchAll();
        }

        public function getVendedor($cuit)
        {
            $cuit = $this->db->escape($cuit);
            if(!ctype_digit($cuit)) throw new ValidacionException('Error: tipo no numero');
            if($cuit < 1) throw new ValidacionException('Error: numero negativo ');

            $this->db->query("SELECT * FROM vendedor
                                LEFT JOIN cliente ON
                                vendedor.cliente = cliente.id_cliente
                                    WHERE cuit = '$cuit'
                                        LIMIT 1");

            return $this->db->fetch();
        }
        
        public function newVendedor($cliente)
        {
            $cliente = $this->db->escape($cliente);
            if(!ctype_digit($cliente)) throw new ValidacionException('Error: tipo no numero');
            if($cliente < 1) throw new ValidacionException('Error: numero negativo ');

            $this->db->query("INSERT INTO vendedor (cliente)
                             VALUE ('$cliente')");

            return $this->db->insert_id();
        }
    }
?>