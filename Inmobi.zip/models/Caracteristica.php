<?php
    //models/..
    
    class Caracteristica extends Model{
        public function getCaract($id)
        {
            $id = $this->db->escape($id);
            if(!ctype_digit($id)) throw new ValidacionException('Error: tipo no numero');
            if($id < 1) throw new ValidacionException('Error: numero negativo ');

            $this->db->query("SELECT * 
                                FROM caracteristicas
                                    WHERE id_caracteristicas = '$id'
                                        LIMIT 1");
                                            
            return $this->db->fetch();
        }

        public function newCaract($c_array)
        {
            //VALIDACIONES
            if(!is_array($c_array)) throw new ValidacionException('Error: tipo no array');

            foreach($c_array as $v)
            {
                if(!is_bool($v)) throw new ValidacionException('Error: tipo no bool');
            }

            $terraza = $c_array['terraza'];
            $garage = $c_array['garage'];
            $balcon = $c_array['balcon'];
            $pileta = $c_array['pileta'];
            $patio = $c_array['patio'];
            $jardin = $c_array['jardin'];

            $this->db->query("INSERT INTO caracteristicas (terraza, garage, balcon, pileta, patio, jardin)
                                VALUES ('$terraza','$garage', '$balcon', '$pileta', '$patio', '$jardin')");
            
            // RETORNA EL ID DE LA ULTIMA FILA INGRESADA EN CARACTERISTICAS  
            return $this->db->insert_id();
        }
    }
?>