<?php
    //views/..

    class vCrearCliente extends View{
        public $type;
        public $cond;
        public $prov;
        public $loc;
        public $client;
    }
?>