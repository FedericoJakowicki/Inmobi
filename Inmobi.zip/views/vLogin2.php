<?php
    //views/..

    class vLogin2 extends View{
        public $user;
    }
?>