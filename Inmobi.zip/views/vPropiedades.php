<?php
    //views/..

    class vPropiedades extends View{
        public $prop;  
        public $prov;
        public $prefProv;
        public $prefOp;
    }
?>