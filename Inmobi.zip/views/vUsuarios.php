<?php
    //views/..

    class vUsuarios extends View{
        public $user;
        public $selected;
    }
?>