<?php
    //views/..

    class vRegistros extends View{
        public $task;
        public $user;
        public $userTask;
    }
?>