<?php
    //views/..
    

    class vLogin1 extends View{
        
    }
?>