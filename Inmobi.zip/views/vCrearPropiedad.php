<?php
    //views/..

    class vCrearPropiedad extends View{
        public $clients;
        public $prov;
        public $loc;
        public $cond;
        public $type;
    }
?>