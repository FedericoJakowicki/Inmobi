<?php
    //views/..

    class vCrearUsuario extends View{
        public $user;
    }
?>