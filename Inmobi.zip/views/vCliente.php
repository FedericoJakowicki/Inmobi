<?php
    //views/..

    class vCliente extends View{
        public $client;
        public $pref;
        public $prop;
    }
?>