<?php
    //views/..

    class vClientes extends View{
        public $client;
        public $prov;
        public $prefProv;
        public $prefTipo;
    }
?>