<?php
    //views/..

    class vPropiedad extends View{
        public $prop;
        public $comprador;
    }
?>