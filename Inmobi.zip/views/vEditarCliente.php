<?php
    //views/..

    class vEditarCliente extends View{
        public $client;
        public $pref;
        public $prov;
        public $loc;
        public $tipo;
        public $estado;
    }
?>